<?php
/**
 * Generic archive template (categories, tags, dates, authors).
 *
 * @package Scrollhaus
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

get_header();
?>
<main class="page-main" id="world">
    <span class="k"><?php esc_html_e( 'Archive', 'scrollhaus' ); ?></span>
    <?php the_archive_title( '<h1 class="entry-title">', '</h1>' ); ?>
    <?php the_archive_description( '<div class="lede" style="max-width:52ch">', '</div>' ); ?>

    <?php if ( have_posts() ) : ?>
        <div class="posts-grid">
            <?php while ( have_posts() ) : ?>
                <?php the_post(); ?>
                <article id="post-<?php the_ID(); ?>" <?php post_class( 'post-row' ); ?>>
                    <?php scrollhaus_posted_on(); ?>
                    <a href="<?php the_permalink(); ?>"><span class="d"><?php the_title(); ?></span></a>
                    <div class="small"><?php the_excerpt(); ?></div>
                </article>
            <?php endwhile; ?>
        </div>
        <?php the_posts_pagination( array( 'mid_size' => 2 ) ); ?>
    <?php else : ?>
        <p><?php esc_html_e( 'Nothing has been published here yet.', 'scrollhaus' ); ?></p>
    <?php endif; ?>
</main>
<?php
get_footer();
