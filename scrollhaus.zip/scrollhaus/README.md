# Scrollhaus — Scroll-Driven Portfolio WordPress Theme

**Version 1.0.0 · GPL-2.0-or-later · by Cerium Web Development**

Scrollhaus is a WordPress classic theme for designers, photographers, illustrators and freelancers. The homepage is a scroll-driven scene: a drawn line carries visitors through your hero, about, stats, journey, services and selected work. Everything else — projects, pages, blog — is standard, fast WordPress.

## Install

1. WordPress dashboard → **Appearance → Themes → Add New → Upload Theme**, upload the theme zip, activate.
2. **Appearance → Scrollhaus Demo** → *Import demo content* (once). This creates:
   - 6 fictional demo projects with details, disciplines and placeholder artwork
   - Services and FAQ pages (with the right page templates)
   - A static **Home** front page
   - The demo persona in the Customizer (only where you haven't set anything yet)
   
   The import is idempotent — running it again skips anything that already exists and never overwrites your Customizer settings.
3. **Appearance → Customize → Scrollhaus** and replace the demo persona with you.

## The Customizer (Appearance → Customize → Scrollhaus)

| Section | What it controls |
| --- | --- |
| **Identity** | Display name (the giant hero type), role, location, "designing since" year, contact email, portrait image, availability badge |
| **Homepage Copy** | Hero lede, about heading + text, work heading, contact heading + text, call-to-action label |
| **Stats** | The three "by the numbers" figures (value + label each). Stat 2 counts up in the scene when its value starts with a number, e.g. `180+` |
| **Services** | One service per line: `Name \| item, item, item` |
| **Journey** | One milestone per line: `Year \| Title \| Text` |
| **FAQ Page Items** | One item per line: `Question \| Answer` — shown on any page using the *Scrollhaus FAQ* template |
| **Colors** | Accent/line colour, background, ink. The accent recolors the drawn line everywhere |
| **Social Links** | Instagram, Behance, Dribbble, LinkedIn, X — shown in the footer and contact section |
| **Footer** | Footer note text |

## Adding projects

**Projects → Add New:**

- **Title + editor content** — the full case-study text.
- **Featured image** — the cover. Used on the homepage card (cropped to the card's aspect) and at the top of the project panel gallery. Recommended: 1200×900 or larger.
- **Disciplines** (right sidebar) — e.g. *Brand Identity*. Shown on cards and in the panel.
- **Project Details box** — Client, Year, Location, Project URL, Summary (the short text shown before the full description).
- **Project Gallery box** — *Add images* opens the media library; images appear in the panel's scrolling gallery in order. Remove and re-add to reorder.

Homepage cards are generated automatically from published projects, in **menu order** (drag in the Projects list with a menu-order plugin, or set Order under Page Attributes). Cards cycle through six layout positions, so any number of projects works — 3, 6, 9, 20.

## Pages

- **Services template** (*Scrollhaus Services*) — renders the page content, the Customizer services grid, and a four-step process list.
- **FAQ template** (*Scrollhaus FAQ*) — renders the page content plus the Customizer FAQ items as native `<details>` accordions (no JavaScript needed).
- **Work archive** — lives at `/work/` automatically; a grid of all projects.
- **Project singles** — live at `/projects/your-project/`; sticky info column + scrolling gallery, with prev/next project links and a close button back to the homepage card.

## Menus

- **Primary Menu** (optional) — if you assign one, it replaces the default scene-anchor list in the overlay menu.
- **Footer Menu** (optional) — small-print links in the footer.
- **Custom Logo** (Site Identity) — replaces the text name mark in the top bar.

## Good to know

- **No JavaScript?** The homepage stacks into a normal, readable page. The scene is an enhancement, never a requirement.
- **Reduced motion** is respected: the engine stops smoothing and CSS animations are disabled.
- **Performance** — scene CSS/JS load only on the front page and project singles.
- **Child themes** — all features live in `inc/` files loaded from `functions.php`; templates use standard WordPress hooks and filters.

## Support

Theme documentation is also included as `docs/documentation.html` inside the theme folder — open it in any browser. For help, contact Cerium Web Development via the marketplace you purchased from.

## License

Scrollhaus is released under the GNU General Public License v2 or later. Demo artwork (abstract SVGs in `assets/demo/`) is included under the same license. Fonts are loaded from Google Fonts and remain under their respective OFL licenses.
