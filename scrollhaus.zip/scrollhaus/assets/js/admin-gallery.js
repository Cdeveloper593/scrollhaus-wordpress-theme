/**
 * Scrollhaus — admin gallery uploader.
 *
 * Manages the Project Gallery meta box: opens the WordPress media frame,
 * renders thumbnails, keeps the hidden ID list in sync.
 */
(function ($) {
    'use strict';

    var frame = null;

    function syncIds($box) {
        var ids = [];
        $box.find('.scrollhaus-gallery-list li').each(function () {
            ids.push($(this).data('id'));
        });
        $box.find('#scrollhaus_gallery_ids').val(ids.join(','));
    }

    $(document).on('click', '.scrollhaus-gallery-add', function (event) {
        event.preventDefault();
        var $box = $(this).closest('.scrollhaus-gallery-box');

        if (frame) {
            frame.open();
            return;
        }

        frame = wp.media({
            title: window.scrollhausGallery ? window.scrollhausGallery.title : 'Choose gallery images',
            button: { text: window.scrollhausGallery ? window.scrollhausGallery.button : 'Add to gallery' },
            multiple: true,
            library: { type: 'image' }
        });

        frame.on('select', function () {
            var selection = frame.state().get('selection');
            selection.each(function (attachment) {
                var data = attachment.toJSON();
                var thumb = (data.sizes && data.sizes.thumbnail) ? data.sizes.thumbnail.url : data.url;
                var $item = $('<li></li>').attr('data-id', data.id).css('position', 'relative');
                $('<img alt="">').attr('src', thumb).css({
                    width: '80px', height: '80px', objectFit: 'cover', display: 'block'
                }).appendTo($item);
                $('<button type="button" class="button-link scrollhaus-gallery-remove"></button>')
                    .text(window.scrollhausGallery ? window.scrollhausGallery.remove : 'Remove')
                    .css({ display: 'block', marginTop: '4px' })
                    .appendTo($item);
                $box.find('.scrollhaus-gallery-list').append($item);
            });
            syncIds($box);
        });

        frame.open();
    });

    $(document).on('click', '.scrollhaus-gallery-remove', function (event) {
        event.preventDefault();
        var $item = $(this).closest('li');
        var $box = $item.closest('.scrollhaus-gallery-box');
        $item.remove();
        syncIds($box);
    });
})(jQuery);
