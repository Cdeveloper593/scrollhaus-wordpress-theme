<?php
/**
 * Default page template.
 *
 * @package Scrollhaus
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

get_header();
?>
<main class="page-main" id="world">
    <?php while ( have_posts() ) : ?>
        <?php the_post(); ?>
        <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
            <h1 class="entry-title"><?php the_title(); ?></h1>
            <?php if ( has_post_thumbnail() ) : ?>
                <?php the_post_thumbnail( 'scrollhaus-gallery' ); ?>
            <?php endif; ?>
            <div class="entry-content">
                <?php the_content(); ?>
                <?php
                wp_link_pages(
                    array(
                        'before' => '<div class="pagination">',
                        'after'  => '</div>',
                    )
                );
                ?>
            </div>
        </article>
        <?php
        if ( comments_open() || get_comments_number() ) {
            comments_template();
        }
        ?>
    <?php endwhile; ?>
</main>
<?php
get_footer();
