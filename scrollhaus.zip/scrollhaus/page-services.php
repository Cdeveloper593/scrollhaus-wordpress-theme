<?php
/**
 * Template Name: Scrollhaus Services
 *
 * Services page: the Customizer services list as a grid, plus the page's
 * own content and a simple process list.
 *
 * @package Scrollhaus
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

get_header();

$services = scrollhaus_services_parsed();
$steps    = array(
    array( __( 'Discover', 'scrollhaus' ), __( 'A short call and a deep look at your market, audience and competitors. We agree the problem before touching design.', 'scrollhaus' ) ),
    array( __( 'Direction', 'scrollhaus' ), __( 'Two or three distinct creative directions, presented with real words and real imagery — never lorem ipsum on a blank board.', 'scrollhaus' ) ),
    array( __( 'Design', 'scrollhaus' ), __( 'The chosen direction is built out across every touchpoint: identity, print, digital and the odd thing nobody planned for.', 'scrollhaus' ) ),
    array( __( 'Deliver', 'scrollhaus' ), __( 'Final files, a compact playbook and a handover call, so the brand keeps looking like itself long after launch.', 'scrollhaus' ) ),
);
?>
<main class="page-main" id="world">
    <?php while ( have_posts() ) : ?>
        <?php the_post(); ?>
        <span class="k"><?php esc_html_e( 'Services', 'scrollhaus' ); ?></span>
        <h1 class="entry-title"><?php the_title(); ?></h1>
        <div class="entry-content">
            <?php the_content(); ?>
        </div>
    <?php endwhile; ?>

    <div class="info-grid" style="margin-top:3em">
        <?php foreach ( $services as $service ) : ?>
            <div>
                <h3><?php echo esc_html( $service['name'] ); ?></h3>
                <?php if ( $service['items'] ) : ?>
                    <ul>
                        <?php foreach ( $service['items'] as $item ) : ?>
                            <li><?php echo esc_html( $item ); ?></li>
                        <?php endforeach; ?>
                    </ul>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
    </div>

    <h2 class="entry-title" style="font-size:clamp(32px,4.4vw,52px);margin-top:2em"><?php esc_html_e( 'How it works', 'scrollhaus' ); ?></h2>
    <ol class="steps">
        <?php foreach ( $steps as $step ) : ?>
            <li>
                <b><?php echo esc_html( $step[0] ); ?></b>
                <?php echo esc_html( $step[1] ); ?>
            </li>
        <?php endforeach; ?>
    </ol>

    <a class="cta" href="<?php echo esc_url( home_url( '/#contact' ) ); ?>"><?php esc_html_e( 'Start a project', 'scrollhaus' ); ?></a>
</main>
<?php
get_footer();
