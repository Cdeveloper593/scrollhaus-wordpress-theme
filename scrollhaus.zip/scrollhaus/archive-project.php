<?php
/**
 * Project archive ("Work"): a plain, fast grid of every project.
 *
 * @package Scrollhaus
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

get_header();
?>
<main class="page-main wide" id="world">
    <span class="k"><?php esc_html_e( 'Archive', 'scrollhaus' ); ?></span>
    <h1 class="entry-title"><?php esc_html_e( 'Work', 'scrollhaus' ); ?></h1>
    <p class="lede" style="max-width:52ch"><?php esc_html_e( 'Every project, in one grid. For the full experience, start from the homepage and follow the line.', 'scrollhaus' ); ?></p>

    <?php if ( have_posts() ) : ?>
        <div class="work-grid">
            <?php $grid_index = 0; ?>
            <?php while ( have_posts() ) : ?>
                <?php the_post(); ?>
                <?php $grid_index++; ?>
                <a class="work-card" href="<?php the_permalink(); ?>">
                    <span class="fig">
                        <?php if ( has_post_thumbnail() ) : ?>
                            <?php the_post_thumbnail( 'scrollhaus-cover', array( 'alt' => esc_attr( get_the_title() ) ) ); ?>
                        <?php else : ?>
                            <img src="<?php echo esc_url( get_template_directory_uri() . '/assets/demo/project-' . ( ( ( $grid_index - 1 ) % 6 ) + 1 ) . '.svg' ); ?>" alt="<?php echo esc_attr( get_the_title() ); ?>" />
                        <?php endif; ?>
                    </span>
                    <span class="meta">
                        <span class="mono"><?php echo esc_html( str_pad( (string) $grid_index, 2, '0', STR_PAD_LEFT ) ); ?></span>
                        <span class="mono"><?php echo esc_html( scrollhaus_project_meta( 'year' ) ); ?></span>
                    </span>
                    <span class="d"><?php the_title(); ?></span>
                </a>
            <?php endwhile; ?>
        </div>
        <?php the_posts_pagination( array( 'mid_size' => 2 ) ); ?>
    <?php else : ?>
        <p><?php esc_html_e( 'No projects yet. Add your first project from the WordPress dashboard, or run the demo import under Appearance → Scrollhaus Demo.', 'scrollhaus' ); ?></p>
    <?php endif; ?>
</main>
<?php
get_footer();
