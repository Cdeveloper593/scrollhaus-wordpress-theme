<?php
/**
 * The footer: small print, footer menu and socials.
 *
 * The big contact call-to-action lives in front-page.php; this footer is
 * intentionally quiet.
 *
 * @package Scrollhaus
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

$scrollhaus_name = (string) scrollhaus_mod( 'scrollhaus_display_name', get_bloginfo( 'name' ) );
$scrollhaus_note = (string) scrollhaus_mod( 'scrollhaus_footer_note', '' );
?>
<footer class="site-foot">
    <span>&copy; <?php echo esc_html( gmdate( 'Y' ) ); ?> <?php echo esc_html( $scrollhaus_name ); ?></span>
    <?php if ( '' !== $scrollhaus_note ) : ?>
        <span><?php echo esc_html( $scrollhaus_note ); ?></span>
    <?php endif; ?>
    <?php
    if ( has_nav_menu( 'footer' ) ) {
        wp_nav_menu(
            array(
                'theme_location' => 'footer',
                'container'      => 'nav',
                'container_aria_label' => esc_attr__( 'Footer', 'scrollhaus' ),
                'menu_class'     => 'foot-menu',
                'depth'          => 1,
            )
        );
    }
    ?>
    <?php scrollhaus_the_socials(); ?>
</footer>
<?php wp_footer(); ?>
</body>
</html>
