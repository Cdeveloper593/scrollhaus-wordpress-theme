<?php
/**
 * Single project: settled panel layout.
 *
 * Sticky left info column (title, meta table, summary, description,
 * prev/next) beside a scrolling gallery built from the featured image
 * plus the _scrollhaus_gallery attachments.
 *
 * @package Scrollhaus
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

get_header();

while ( have_posts() ) :
    the_post();
    $project_id  = get_the_ID();
    $client      = scrollhaus_project_meta( 'client', $project_id );
    $year        = scrollhaus_project_meta( 'year', $project_id );
    $loc         = scrollhaus_project_meta( 'location', $project_id );
    $url         = scrollhaus_project_meta( 'url', $project_id );
    $summary     = scrollhaus_project_meta( 'summary', $project_id );
    $discipline  = scrollhaus_project_disciplines( $project_id );
    $gallery_ids = scrollhaus_project_gallery_ids( $project_id );
    $next_post   = get_adjacent_post( false, '', false );
    $prev_post   = get_adjacent_post( false, '', true );
    $work_anchor = home_url( '/#project-' . get_post_field( 'post_name', $project_id ) );
    ?>
    <a class="pv-x" href="<?php echo esc_url( $work_anchor ); ?>" aria-label="<?php esc_attr_e( 'Close project and return to the work list', 'scrollhaus' ); ?>">&times;</a>

    <main class="pv" id="world">
        <div class="pv-l">
            <span class="mono"><?php echo esc_html( $discipline ); ?></span>
            <h1 class="d"><?php the_title(); ?></h1>

            <dl class="pv-dl">
                <?php if ( '' !== $client ) : ?>
                    <dt><?php esc_html_e( 'Client', 'scrollhaus' ); ?></dt>
                    <dd><?php echo esc_html( $client ); ?></dd>
                <?php endif; ?>
                <?php if ( '' !== $year ) : ?>
                    <dt><?php esc_html_e( 'Year', 'scrollhaus' ); ?></dt>
                    <dd><?php echo esc_html( $year ); ?></dd>
                <?php endif; ?>
                <?php if ( '' !== $loc ) : ?>
                    <dt><?php esc_html_e( 'Location', 'scrollhaus' ); ?></dt>
                    <dd><?php echo esc_html( $loc ); ?></dd>
                <?php endif; ?>
                <?php if ( '' !== $discipline ) : ?>
                    <dt><?php esc_html_e( 'Discipline', 'scrollhaus' ); ?></dt>
                    <dd><?php echo esc_html( $discipline ); ?></dd>
                <?php endif; ?>
                <?php if ( '' !== $url ) : ?>
                    <dt><?php esc_html_e( 'Visit', 'scrollhaus' ); ?></dt>
                    <dd><a href="<?php echo esc_url( $url ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Live project', 'scrollhaus' ); ?></a></dd>
                <?php endif; ?>
            </dl>

            <?php if ( '' !== $summary ) : ?>
                <p class="pv-summary"><?php echo esc_html( $summary ); ?></p>
            <?php endif; ?>

            <div class="entry-content">
                <?php the_content(); ?>
            </div>

            <?php if ( $next_post ) : ?>
                <a class="pv-next" href="<?php echo esc_url( get_permalink( $next_post ) ); ?>">
                    <span class="mono"><?php esc_html_e( 'Next project', 'scrollhaus' ); ?></span>
                    <span class="d"><?php echo esc_html( get_the_title( $next_post ) ); ?></span>
                </a>
            <?php endif; ?>
            <?php if ( $prev_post ) : ?>
                <a class="pv-next" href="<?php echo esc_url( get_permalink( $prev_post ) ); ?>">
                    <span class="mono"><?php esc_html_e( 'Previous project', 'scrollhaus' ); ?></span>
                    <span class="d"><?php echo esc_html( get_the_title( $prev_post ) ); ?></span>
                </a>
            <?php endif; ?>
        </div>

        <div class="pv-r">
            <?php if ( has_post_thumbnail() ) : ?>
                <figure>
                    <?php the_post_thumbnail( 'scrollhaus-gallery', array( 'alt' => esc_attr( get_the_title() ) ) ); ?>
                </figure>
            <?php endif; ?>
            <?php foreach ( $gallery_ids as $attachment_id ) : ?>
                <figure>
                    <?php
                    echo wp_get_attachment_image(
                        $attachment_id,
                        'scrollhaus-gallery',
                        false,
                        array( 'loading' => 'lazy', 'alt' => esc_attr( get_the_title() ) )
                    );
                    $caption = wp_get_attachment_caption( $attachment_id );
                    if ( $caption ) {
                        echo '<figcaption class="small" style="padding:8px 2px">' . esc_html( $caption ) . '</figcaption>';
                    }
                    ?>
                </figure>
            <?php endforeach; ?>
            <?php if ( ! has_post_thumbnail() && ! $gallery_ids ) : ?>
                <figure>
                    <img src="<?php echo esc_url( get_template_directory_uri() . '/assets/demo/project-1.svg' ); ?>" alt="<?php echo esc_attr( get_the_title() ); ?>" />
                </figure>
            <?php endif; ?>
        </div>
    </main>
    <?php
endwhile;

get_footer();
