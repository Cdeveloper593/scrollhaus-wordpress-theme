<?php
/**
 * Single blog post template.
 *
 * @package Scrollhaus
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

get_header();
?>
<main class="page-main" id="world">
    <?php while ( have_posts() ) : ?>
        <?php the_post(); ?>
        <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
            <?php scrollhaus_posted_on(); ?>
            <h1 class="entry-title"><?php the_title(); ?></h1>
            <?php if ( has_post_thumbnail() ) : ?>
                <?php the_post_thumbnail( 'scrollhaus-gallery' ); ?>
            <?php endif; ?>
            <div class="entry-content">
                <?php the_content(); ?>
                <?php
                wp_link_pages(
                    array(
                        'before' => '<div class="pagination">',
                        'after'  => '</div>',
                    )
                );
                ?>
            </div>
            <?php the_tags( '<ul class="tags"><li>', '</li><li>', '</li></ul>' ); ?>
        </article>

        <nav class="pagination" aria-label="<?php esc_attr_e( 'Post navigation', 'scrollhaus' ); ?>">
            <?php previous_post_link( '%link', esc_html__( '← Previous post', 'scrollhaus' ) ); ?>
            <?php next_post_link( '%link', esc_html__( 'Next post →', 'scrollhaus' ) ); ?>
        </nav>

        <?php
        if ( comments_open() || get_comments_number() ) {
            comments_template();
        }
        ?>
    <?php endwhile; ?>
</main>
<?php
get_footer();
