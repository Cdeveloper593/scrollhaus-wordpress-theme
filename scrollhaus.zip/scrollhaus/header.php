<?php
/**
 * The header: document head, top bar and overlay menu.
 *
 * The overlay menu lists the homepage scene anchors. On the front page the
 * scene script intercepts them (data-go); anywhere else they link back to
 * the homepage with a hash, which the scene honours on arrival.
 *
 * @package Scrollhaus
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<link rel="profile" href="https://gmpg.org/xfn/11" />
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="screen-reader-text" href="#world"><?php esc_html_e( 'Skip to content', 'scrollhaus' ); ?></a>

<header class="bar">
    <?php scrollhaus_the_mark(); ?>
    <button class="burger" id="burger" type="button" aria-expanded="false" aria-controls="menu">
        <span class="mono" style="color:inherit"><?php esc_html_e( 'Menu', 'scrollhaus' ); ?></span>
        <i aria-hidden="true"></i>
    </button>
</header>

<nav id="menu" aria-label="<?php esc_attr_e( 'Main', 'scrollhaus' ); ?>">
    <?php if ( has_nav_menu( 'primary' ) ) : ?>
        <?php
        wp_nav_menu(
            array(
                'theme_location' => 'primary',
                'container'      => false,
                'menu_class'     => 'menu-list',
                'items_wrap'     => '<ol id="%1$s" class="%2$s">%3$s</ol>',
                'depth'          => 1,
            )
        );
        ?>
    <?php else : ?>
        <?php
        $scrollhaus_anchors = array(
            'about'    => __( 'About', 'scrollhaus' ),
            'journey'  => __( 'Journey', 'scrollhaus' ),
            'services' => __( 'What I Do', 'scrollhaus' ),
            'work'     => __( 'Work', 'scrollhaus' ),
            'contact'  => __( 'Contact', 'scrollhaus' ),
        );
        $scrollhaus_front   = is_front_page();
        ?>
        <ol>
            <?php $scrollhaus_i = 0; ?>
            <?php foreach ( $scrollhaus_anchors as $scrollhaus_id => $scrollhaus_label ) : ?>
                <?php $scrollhaus_i++; ?>
                <li>
                    <a href="<?php echo esc_url( $scrollhaus_front ? '#' . $scrollhaus_id : home_url( '/#' . $scrollhaus_id ) ); ?>" data-go="<?php echo esc_attr( $scrollhaus_id ); ?>">
                        <span class="mono"><?php echo esc_html( str_pad( (string) $scrollhaus_i, 2, '0', STR_PAD_LEFT ) ); ?></span>
                        <span class="d"><?php echo esc_html( $scrollhaus_label ); ?></span>
                    </a>
                </li>
            <?php endforeach; ?>
        </ol>
    <?php endif; ?>
    <div class="menu-sub">
        <?php
        $scrollhaus_services_page = get_page_by_path( 'services' );
        $scrollhaus_faq_page      = get_page_by_path( 'faq' );
        ?>
        <?php if ( $scrollhaus_services_page ) : ?>
            <a href="<?php echo esc_url( get_permalink( $scrollhaus_services_page ) ); ?>"><?php esc_html_e( 'Services', 'scrollhaus' ); ?></a>
        <?php endif; ?>
        <?php if ( $scrollhaus_faq_page ) : ?>
            <a href="<?php echo esc_url( get_permalink( $scrollhaus_faq_page ) ); ?>"><?php esc_html_e( 'FAQ', 'scrollhaus' ); ?></a>
        <?php endif; ?>
        <a href="<?php echo esc_url( get_post_type_archive_link( 'project' ) ); ?>"><?php esc_html_e( 'All Work', 'scrollhaus' ); ?></a>
    </div>
</nav>
