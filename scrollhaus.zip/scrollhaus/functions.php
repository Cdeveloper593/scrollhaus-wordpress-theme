<?php
/**
 * Scrollhaus theme bootstrap.
 *
 * Loads the modular includes in /inc. Keep this file thin: every feature
 * lives in its own file so buyers (and child themes) can follow along.
 *
 * @package Scrollhaus
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'SCROLLHAUS_VERSION', '1.0.0' );

$scrollhaus_includes = array(
    'inc/setup.php',
    'inc/helpers.php',
    'inc/template-tags.php',
    'inc/cpt.php',
    'inc/meta-boxes.php',
    'inc/enqueue.php',
    'inc/customizer.php',
    'inc/customizer-css.php',
    'inc/demo-import.php',
);

foreach ( $scrollhaus_includes as $scrollhaus_file ) {
    $scrollhaus_path = get_template_directory() . '/' . $scrollhaus_file;
    if ( file_exists( $scrollhaus_path ) ) {
        require_once $scrollhaus_path;
    }
}
unset( $scrollhaus_includes, $scrollhaus_file, $scrollhaus_path );
