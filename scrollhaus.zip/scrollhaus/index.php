<?php
/**
 * The main template file: blog index / fallback for everything.
 *
 * @package Scrollhaus
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

get_header();
?>
<main class="page-main" id="world">
    <?php if ( is_home() && ! is_front_page() ) : ?>
        <span class="k"><?php esc_html_e( 'Notes', 'scrollhaus' ); ?></span>
        <h1 class="entry-title"><?php echo esc_html( single_post_title( '', false ) ); ?></h1>
    <?php endif; ?>

    <?php if ( have_posts() ) : ?>
        <div class="posts-grid">
            <?php while ( have_posts() ) : ?>
                <?php the_post(); ?>
                <article id="post-<?php the_ID(); ?>" <?php post_class( 'post-row' ); ?>>
                    <?php scrollhaus_posted_on(); ?>
                    <a href="<?php the_permalink(); ?>"><span class="d"><?php the_title(); ?></span></a>
                    <div class="small"><?php the_excerpt(); ?></div>
                </article>
            <?php endwhile; ?>
        </div>
        <?php the_posts_pagination( array( 'mid_size' => 2 ) ); ?>
    <?php else : ?>
        <h1 class="entry-title"><?php esc_html_e( 'Nothing here yet', 'scrollhaus' ); ?></h1>
        <p><?php esc_html_e( 'There is no content to show yet. Add a post or a project from the dashboard to get started.', 'scrollhaus' ); ?></p>
    <?php endif; ?>
</main>
<?php
get_footer();
