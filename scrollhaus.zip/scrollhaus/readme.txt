=== Scrollhaus ===
Contributors: ceriumwebdevelopment
Tags: portfolio, one-column, custom-colors, custom-logo, custom-menu, featured-images, theme-options, translation-ready, blog
Requires at least: 6.3
Tested up to: 6.7
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A scroll-driven portfolio theme for designers, photographers, illustrators and freelancers.

== Description ==

Scrollhaus turns your homepage into a short film about your practice. Visitors scroll, and a hand-drawn line carries them through your name, your story, your numbers, your journey, your services and your selected work — every project flying in as a card on the line.

Underneath the show, Scrollhaus is a plain, well-behaved WordPress theme:

* A **Projects** post type with a details meta box (client, year, location, URL, summary) and a media-library gallery.
* A **Disciplines** taxonomy for organising work.
* A full **Customizer** panel: identity, homepage copy, stats, services, journey milestones, FAQ items, colours and socials. No code required.
* A one-click **demo import** (Appearance → Scrollhaus Demo) with fictional demo content you can replace piece by piece.
* Services and FAQ page templates using native, accessible markup — the FAQ works with JavaScript disabled.
* A classic project archive grid, blog templates, search and a friendly 404.
* Fully responsive, reduced-motion aware, and readable with JavaScript off.

== Installation ==

1. In your WordPress dashboard, go to Appearance → Themes → Add New → Upload Theme.
2. Upload `scrollhaus.zip` and activate the theme.
3. (Recommended) Go to Appearance → Scrollhaus Demo and run the demo import once. It creates the demo projects, Services and FAQ pages, sets a static homepage and fills in the demo persona.
4. Go to Appearance → Customize → Scrollhaus and make it yours: name, role, colours, services, journey, stats and socials.
5. Replace the demo projects under Projects with your own work.

== Frequently Asked Questions ==

= How do I add a project? =
Projects → Add New. Give it a title, a cover image (Featured Image), a discipline, and fill in the Project Details and Project Gallery boxes. It appears on the homepage automatically, in menu order.

= How do I change the homepage text? =
Everything on the homepage is in Appearance → Customize → Scrollhaus: identity, hero and about copy, the three stats, the services list, journey milestones and the contact section.

= How do the services / journey / FAQ text boxes work? =
One item per line, with a simple format:
Services: `Name | item, item, item`
Journey: `Year | Title | Text`
FAQ: `Question | Answer`

= Can I change the accent colour? =
Yes — Customizer → Scrollhaus → Colors. The accent drives the drawn line, links and highlights across the whole site.

= Does the homepage work without JavaScript? =
Yes. The scroll scene is an enhancement; without JavaScript every section stacks in order and stays fully readable.

= Which fonts does the theme use? =
Bebas Neue, DM Serif Display, Inter and Space Mono — all free Google Fonts, loaded from Google's CDN.

== Changelog ==

= 1.0.0 =
* Initial release: scroll-driven homepage scene, Projects post type with gallery meta box, full Customizer panel, demo import, Services and FAQ templates, work archive, blog templates.

== Credits ==

Scrollhaus is an original theme by Cerium Web Development. Demo artwork is abstract SVG generated for this theme. Fonts: Bebas Neue (Dharma Type, OFL), DM Serif Display (Colophon, OFL), Inter (Rasmus Andersson, OFL), Space Mono (Colophon, OFL).
