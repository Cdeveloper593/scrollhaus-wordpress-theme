<?php
/**
 * One-click demo import: Appearance → Scrollhaus Demo.
 *
 * Creates the fictional Alex Mercer demo content — six projects with
 * meta, disciplines and SVG cover/gallery images, Services and FAQ
 * pages, a static Home front page, and the persona Customizer defaults.
 * Everything is idempotent: existing content (matched by slug) is
 * skipped, and theme mods are only set when they are not already set.
 * Nothing here ever runs automatically.
 *
 * @package Scrollhaus
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * The six fictional demo projects.
 *
 * @return array<int, array<string,mixed>>
 */
function scrollhaus_demo_projects() {
    return array(
        array(
            'slug'       => 'marrow',
            'title'      => 'Marrow',
            'discipline' => 'Restaurant Identity',
            'client'     => 'Marrow Hospitality Group',
            'year'       => '2025',
            'location'   => 'Portland, Oregon',
            'summary'    => 'A warm, bone-deep identity for a wood-fire restaurant — charred type, ember orange and menus that read like short stories.',
            'description' => "Marrow started as a twelve-seat counter and a chef with strong opinions about smoke. The identity had to feel like the food: direct, a little primal, never fussy.\n\nWe built the system around a single heavy grotesque, set tight and slightly scorched at the edges, with an ember-orange accent used sparingly — on the matchboxes, the menu clips and the glow of the signage at night. Everything else is bone, ash and paper.\n\nThe restaurant doubled its covers within a year and the identity stretched with it, from the original counter to a second dining room and a line of bottled sauces.",
            'services'   => array( 'Logo and identity system', 'Menu and print design', 'Signage and wayfinding' ),
            'cover'      => 'project-1.svg',
            'gallery'    => array( 'project-2.svg', 'project-3.svg' ),
        ),
        array(
            'slug'       => 'northpeak-outdoors',
            'title'      => 'Northpeak Outdoors',
            'discipline' => 'Brand Identity',
            'client'     => 'Northpeak Outdoors Co.',
            'year'       => '2024',
            'location'   => 'Bend, Oregon',
            'summary'    => 'A rugged rebrand for a Pacific Northwest outdoor retailer — contour-line graphics, trail-marker typography and a flag you can spot from the ridge.',
            'description' => "Northpeak had outgrown its clip-art mountain. The new identity draws its graphics straight from topographic maps of the Cascades: every pattern in the system is a real contour line from a real trail the staff actually hike.\n\nThe wordmark is set in a sturdy, trail-marker style and paired with a simple peak flag that works embroidered on a cuff, stamped on a crate or painted six feet tall on the flagship store.\n\nSales of own-brand gear rose sharply after launch, and the contour system now covers packaging, vehicle livery and the annual catalogue.",
            'services'   => array( 'Brand strategy and naming support', 'Identity and packaging', 'Retail graphics and livery' ),
            'cover'      => 'project-2.svg',
            'gallery'    => array( 'project-4.svg', 'project-1.svg' ),
        ),
        array(
            'slug'       => 'lumen-gallery',
            'title'      => 'Lumen Gallery',
            'discipline' => 'Art Direction',
            'client'     => 'Lumen Contemporary',
            'year'       => '2025',
            'location'   => 'Seattle, Washington',
            'summary'    => 'Seasonal art direction for a contemporary gallery — each exhibition gets a light condition, a colour temperature and a type treatment of its own.',
            'description' => "Lumen shows four exhibitions a year and wanted each one to feel like walking into a different quality of light. Instead of a fixed campaign style, we designed a framework: the gallery's name stays put while colour temperature, imagery and typography shift with the season's work.\n\nSpring opened cool and architectural; summer went overexposed and loud. Posters, invitations, wall text and the social campaign all run off the same grid, so the system is fast to produce but never looks templated.\n\nAttendance for the first two seasons beat the gallery's previous records, and the framework is now in its second year.",
            'services'   => array( 'Campaign concepts', 'Poster and invitation design', 'Social and digital assets' ),
            'cover'      => 'project-3.svg',
            'gallery'    => array( 'project-5.svg', 'project-6.svg' ),
        ),
        array(
            'slug'       => 'fern-botanics',
            'title'      => 'Fern Botanics',
            'discipline' => 'Packaging',
            'client'     => 'Fern Botanics Ltd.',
            'year'       => '2023',
            'location'   => 'Vancouver, BC',
            'summary'    => 'Packaging for a small-batch botanical skincare line — pressed-fern illustrations, apothecary structure and colour coded by plant family.',
            'description' => "Fern Botanics makes skincare in batches of two hundred, from plants grown within a day's drive of the studio. The packaging needed to feel grown, not manufactured.\n\nWe commissioned pressed-plant illustrations for each hero ingredient and built the labels on an apothecary grid: Latin name first, common name second, batch number stamped by hand. Colour is coded by plant family, so returning customers can find their shelf by hue alone.\n\nThe line launched in eleven independent stores and sold through its first two batches; the system now extends to candles and a small range of teas.",
            'services'   => array( 'Packaging design', 'Illustration direction', 'Label and carton systems' ),
            'cover'      => 'project-4.svg',
            'gallery'    => array( 'project-6.svg', 'project-2.svg' ),
        ),
        array(
            'slug'       => 'tempo-studio',
            'title'      => 'Tempo Studio',
            'discipline' => 'Web & Digital',
            'client'     => 'Tempo Pilates Studio',
            'year'       => '2026',
            'location'   => 'Austin, Texas',
            'summary'    => 'A rhythm-led website and booking flow for a pilates studio — metronome motifs, breath-paced animation and a timetable you can read at a glance.',
            'description' => "Tempo's classes run to a beat, so the website does too. The design uses a metronome motif throughout — tick marks for the timetable, a swinging accent in the hero — and animation timed to a resting breath rather than a product demo.\n\nThe booking flow was rebuilt from five steps to two, with the timetable readable at a glance on a phone held in one hand, mid-stretch.\n\nOnline bookings rose by half in the first quarter after launch, and the studio has since opened a second location with the same system.",
            'services'   => array( 'Web design', 'Booking flow UX', 'Motion and social assets' ),
            'cover'      => 'project-5.svg',
            'gallery'    => array( 'project-1.svg', 'project-4.svg' ),
        ),
        array(
            'slug'       => 'halcyon-press',
            'title'      => 'Halcyon Press',
            'discipline' => 'Editorial',
            'client'     => 'Halcyon Press',
            'year'       => '2022',
            'location'   => 'Chicago, Illinois',
            'summary'    => 'An editorial system for an independent publisher — a flexible grid, a serif with opinions and covers designed as a shelf, not as singles.',
            'description' => "Halcyon publishes six essay collections a year and wanted the books to look like they belonged together on a shelf without looking the same. The system gives every title the same spine architecture and grid, then lets each cover argue its own case with type alone.\n\nInside, a warm serif carries the long reads, with wide margins built for pencil notes — Halcyon's readers are annotators.\n\nThe redesigned backlist was picked up by two national retailers, and the system has since covered twenty-one titles.",
            'services'   => array( 'Editorial design', 'Cover system', 'Typesetting and production' ),
            'cover'      => 'project-6.svg',
            'gallery'    => array( 'project-3.svg', 'project-5.svg' ),
        ),
    );
}

/**
 * Register the admin page.
 */
function scrollhaus_demo_admin_menu() {
    add_theme_page(
        esc_html__( 'Scrollhaus Demo Import', 'scrollhaus' ),
        esc_html__( 'Scrollhaus Demo', 'scrollhaus' ),
        'manage_options',
        'scrollhaus-demo',
        'scrollhaus_demo_page_render'
    );
}
add_action( 'admin_menu', 'scrollhaus_demo_admin_menu' );

/**
 * Render the demo import page.
 */
function scrollhaus_demo_page_render() {
    if ( ! current_user_can( 'manage_options' ) ) {
        return;
    }
    ?>
    <div class="wrap">
        <h1><?php esc_html_e( 'Scrollhaus Demo Import', 'scrollhaus' ); ?></h1>
        <p><?php esc_html_e( 'This creates the fictional demo content described in the theme documentation: six projects (with details, disciplines and placeholder artwork), Services and FAQ pages, a static Home front page, and the Alex Mercer persona defaults in the Customizer.', 'scrollhaus' ); ?></p>
        <p><?php esc_html_e( 'It is safe to run more than once — anything that already exists is skipped, and your Customizer settings are never overwritten.', 'scrollhaus' ); ?></p>
        <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
            <input type="hidden" name="action" value="scrollhaus_import_demo" />
            <?php wp_nonce_field( 'scrollhaus_import_demo', 'scrollhaus_demo_nonce' ); ?>
            <?php submit_button( esc_html__( 'Import demo content', 'scrollhaus' ), 'primary', 'submit', false ); ?>
        </form>
    </div>
    <?php
}

/**
 * Handle the import request.
 */
function scrollhaus_handle_demo_import() {
    if ( ! current_user_can( 'manage_options' ) ) {
        wp_die( esc_html__( 'You do not have permission to run the demo import.', 'scrollhaus' ) );
    }
    check_admin_referer( 'scrollhaus_import_demo', 'scrollhaus_demo_nonce' );

    $results = scrollhaus_run_demo_import();

    set_transient( 'scrollhaus_demo_result', $results, 60 );
    wp_safe_redirect( admin_url( 'themes.php?page=scrollhaus-demo' ) );
    exit;
}
add_action( 'admin_post_scrollhaus_import_demo', 'scrollhaus_handle_demo_import' );

/**
 * Show the import result as an admin notice.
 */
function scrollhaus_demo_result_notice() {
    $results = get_transient( 'scrollhaus_demo_result' );
    if ( ! is_array( $results ) ) {
        return;
    }
    delete_transient( 'scrollhaus_demo_result' );
    if ( ! current_user_can( 'manage_options' ) ) {
        return;
    }
    $created = isset( $results['created'] ) ? (int) $results['created'] : 0;
    $skipped = isset( $results['skipped'] ) ? (int) $results['skipped'] : 0;
    printf(
        '<div class="notice notice-success is-dismissible"><p>%s</p></div>',
        esc_html(
            sprintf(
                /* translators: 1: items created, 2: items skipped. */
                __( 'Scrollhaus demo import finished: %1$d item(s) created, %2$d already existed and were skipped. Visit your homepage to see the scene.', 'scrollhaus' ),
                $created,
                $skipped
            )
        )
    );
}
add_action( 'admin_notices', 'scrollhaus_demo_result_notice' );

/**
 * Copy a theme demo SVG into the uploads directory and create an
 * attachment. Returns the attachment ID, or 0 on any failure.
 *
 * @param string $filename File inside assets/demo/.
 * @param int    $parent   Parent post ID.
 * @return int
 */
function scrollhaus_sideload_demo_image( $filename, $parent = 0 ) {
    $source = get_template_directory() . '/assets/demo/' . $filename;
    if ( ! file_exists( $source ) ) {
        return 0;
    }

    // Reuse an existing attachment with the same demo slug if present.
    $existing = get_posts(
        array(
            'post_type'      => 'attachment',
            'name'           => sanitize_title( pathinfo( $filename, PATHINFO_FILENAME ) . '-demo' ),
            'posts_per_page' => 1,
            'fields'         => 'ids',
        )
    );
    if ( $existing ) {
        return (int) $existing[0];
    }

    if ( ! function_exists( 'media_handle_sideload' ) || ! function_exists( 'wp_tempnam' ) ) {
        require_once ABSPATH . 'wp-admin/includes/media.php';
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';
    }

    $tmp = wp_tempnam( $filename );
    if ( ! $tmp ) {
        return 0;
    }
    // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_read_file_put_contents -- copying a bundled theme asset to a temp file for the media API.
    if ( false === file_put_contents( $tmp, file_get_contents( $source ) ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- bundled theme asset.
        wp_delete_file( $tmp );
        return 0;
    }

    if ( ! function_exists( 'media_handle_sideload' ) ) {
        require_once ABSPATH . 'wp-admin/includes/media.php';
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';
    }

    $file_array = array(
        'name'     => $filename,
        'tmp_name' => $tmp,
    );
    $attachment_id = media_handle_sideload( $file_array, $parent, esc_html__( 'Scrollhaus demo artwork', 'scrollhaus' ) );
    if ( is_wp_error( $attachment_id ) ) {
        wp_delete_file( $tmp );
        return 0;
    }
    return (int) $attachment_id;
}

/**
 * Allow SVG uploads — only while the demo import runs (the bundled demo
 * artwork is SVG). The filter is removed again before the import returns.
 *
 * @param array $mimes Allowed mime types.
 * @return array
 */
function scrollhaus_demo_allow_svg( $mimes ) {
    $mimes['svg'] = 'image/svg+xml';
    return $mimes;
}

/**
 * Run the import. Returns counts of created / skipped items.
 *
 * @return array{created:int,skipped:int}
 */
function scrollhaus_run_demo_import() {
    $created = 0;
    $skipped = 0;

    add_filter( 'upload_mimes', 'scrollhaus_demo_allow_svg' );

    /* --- Projects ------------------------------------------------------- */
    foreach ( scrollhaus_demo_projects() as $demo ) {
        $existing = get_page_by_path( $demo['slug'], OBJECT, 'project' );
        if ( $existing ) {
            // Backfill artwork if an earlier import created the project but
            // its images failed to sideload — re-running the import repairs it.
            if ( ! has_post_thumbnail( $existing->ID ) ) {
                $cover_id = scrollhaus_sideload_demo_image( $demo['cover'], $existing->ID );
                if ( $cover_id ) {
                    set_post_thumbnail( $existing->ID, $cover_id );
                }
            }
            if ( ! get_post_meta( $existing->ID, '_scrollhaus_gallery', true ) ) {
                $gallery_ids = array();
                foreach ( $demo['gallery'] as $gallery_file ) {
                    $gallery_id = scrollhaus_sideload_demo_image( $gallery_file, $existing->ID );
                    if ( $gallery_id ) {
                        $gallery_ids[] = $gallery_id;
                    }
                }
                if ( $gallery_ids ) {
                    update_post_meta( $existing->ID, '_scrollhaus_gallery', $gallery_ids );
                }
            }
            $skipped++;
            continue;
        }

        $content = $demo['description'];
        if ( ! empty( $demo['services'] ) ) {
            $content .= "\n\n" . esc_html__( 'What was delivered:', 'scrollhaus' ) . ' ' . implode( ', ', $demo['services'] ) . '.';
        }

        $post_id = wp_insert_post(
            array(
                'post_type'    => 'project',
                'post_status'  => 'publish',
                'post_title'   => $demo['title'],
                'post_name'    => $demo['slug'],
                'post_content' => $content,
                'post_excerpt' => $demo['summary'],
            ),
            true
        );
        if ( is_wp_error( $post_id ) || ! $post_id ) {
            $skipped++;
            continue;
        }
        $created++;

        update_post_meta( $post_id, '_scrollhaus_client', $demo['client'] );
        update_post_meta( $post_id, '_scrollhaus_year', $demo['year'] );
        update_post_meta( $post_id, '_scrollhaus_location', $demo['location'] );
        update_post_meta( $post_id, '_scrollhaus_summary', $demo['summary'] );

        $term = term_exists( $demo['discipline'], 'discipline' );
        if ( ! $term ) {
            $term = wp_insert_term( $demo['discipline'], 'discipline' );
        }
        if ( ! is_wp_error( $term ) && $term ) {
            $term_id = is_array( $term ) ? (int) $term['term_id'] : (int) $term;
            wp_set_object_terms( $post_id, array( $term_id ), 'discipline' );
        }

        $cover_id = scrollhaus_sideload_demo_image( $demo['cover'], $post_id );
        if ( $cover_id ) {
            set_post_thumbnail( $post_id, $cover_id );
        }
        $gallery_ids = array();
        foreach ( $demo['gallery'] as $gallery_file ) {
            $gallery_id = scrollhaus_sideload_demo_image( $gallery_file, $post_id );
            if ( $gallery_id ) {
                $gallery_ids[] = $gallery_id;
            }
        }
        if ( $gallery_ids ) {
            update_post_meta( $post_id, '_scrollhaus_gallery', $gallery_ids );
        }
    }

    /* --- Pages ------------------------------------------------------------ */
    $pages = array(
        array(
            'slug'     => 'services',
            'title'    => esc_html__( 'Services', 'scrollhaus' ),
            'template' => 'page-services.php',
            'content'  => esc_html__( 'Everything a growing brand needs from one designer: strategy that decides, identity that sticks, and the print and digital pieces that carry it into the world. Pick a single discipline or hand over the whole picture.', 'scrollhaus' ),
        ),
        array(
            'slug'     => 'faq',
            'title'    => esc_html__( 'FAQ', 'scrollhaus' ),
            'template' => 'page-faq.php',
            'content'  => esc_html__( 'The questions every client asks before we start — timelines, process, files and working together from another time zone. Anything else, just ask.', 'scrollhaus' ),
        ),
        array(
            'slug'     => 'home',
            'title'    => esc_html__( 'Home', 'scrollhaus' ),
            'template' => '',
            'content'  => '',
        ),
    );

    $home_page_id = 0;
    foreach ( $pages as $page ) {
        $existing_page = get_page_by_path( $page['slug'], OBJECT, 'page' );
        if ( $existing_page ) {
            $skipped++;
            if ( 'home' === $page['slug'] ) {
                $home_page_id = (int) $existing_page->ID;
            }
            continue;
        }
        $page_id = wp_insert_post(
            array(
                'post_type'    => 'page',
                'post_status'  => 'publish',
                'post_title'   => $page['title'],
                'post_name'    => $page['slug'],
                'post_content' => $page['content'],
            ),
            true
        );
        if ( is_wp_error( $page_id ) || ! $page_id ) {
            $skipped++;
            continue;
        }
        $created++;
        if ( '' !== $page['template'] ) {
            update_post_meta( $page_id, '_wp_page_template', $page['template'] );
        }
        if ( 'home' === $page['slug'] ) {
            $home_page_id = (int) $page_id;
        }
    }

    /* --- Reading settings -------------------------------------------------- */
    if ( $home_page_id && 'page' !== get_option( 'show_on_front' ) ) {
        update_option( 'show_on_front', 'page' );
        update_option( 'page_on_front', $home_page_id );
    }

    /* --- Persona theme mods (only when unset) ------------------------------ */
    $persona = array(
        'scrollhaus_display_name' => 'Alex Mercer',
        'scrollhaus_role'         => 'Brand Designer & Art Director',
        'scrollhaus_location'     => 'Portland, Oregon',
        'scrollhaus_since'        => 2012,
        'scrollhaus_email'        => 'hello@example.com',
    );
    foreach ( $persona as $key => $value ) {
        if ( null === get_theme_mod( $key, null ) ) {
            set_theme_mod( $key, $value );
        }
    }

    remove_filter( 'upload_mimes', 'scrollhaus_demo_allow_svg' );
    flush_rewrite_rules();
    return array(
        'created' => $created,
        'skipped' => $skipped,
    );
}
