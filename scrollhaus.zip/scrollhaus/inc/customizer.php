<?php
/**
 * Customizer: identity, homepage copy, stats, services, journey, FAQ,
 * colours and socials. Every setting has an explicit sanitize callback.
 *
 * Textarea formats (documented for buyers in README.md):
 *   Services:  Name | item, item, item          (one per line)
 *   Journey:   Year | Title | Text              (one per line)
 *   FAQ:       Question | Answer                (one per line)
 *
 * @package Scrollhaus
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Sanitize a plain-text Customizer value.
 *
 * @param string $value Raw value.
 * @return string
 */
function scrollhaus_sanitize_text( $value ) {
    return sanitize_text_field( is_string( $value ) ? $value : '' );
}

/**
 * Sanitize a textarea value, keeping line breaks.
 *
 * @param string $value Raw value.
 * @return string
 */
function scrollhaus_sanitize_textarea( $value ) {
    return sanitize_textarea_field( is_string( $value ) ? $value : '' );
}

/**
 * Sanitize a services textarea: strip tags per line, keep the format.
 *
 * @param string $value Raw value.
 * @return string
 */
function scrollhaus_sanitize_services( $value ) {
    $clean = array();
    foreach ( scrollhaus_parse_services_text( sanitize_textarea_field( is_string( $value ) ? $value : '' ) ) as $service ) {
        $clean[] = $service['name'] . ( $service['items'] ? ' | ' . implode( ', ', $service['items'] ) : '' );
    }
    return implode( "\n", $clean );
}

/**
 * Sanitize a journey textarea.
 *
 * @param string $value Raw value.
 * @return string
 */
function scrollhaus_sanitize_journey( $value ) {
    $clean = array();
    foreach ( scrollhaus_parse_journey_text( sanitize_textarea_field( is_string( $value ) ? $value : '' ) ) as $m ) {
        $clean[] = implode( ' | ', array( $m['year'], $m['title'], $m['text'] ) );
    }
    return implode( "\n", $clean );
}

/**
 * Sanitize an FAQ textarea.
 *
 * @param string $value Raw value.
 * @return string
 */
function scrollhaus_sanitize_faq( $value ) {
    $clean = array();
    foreach ( preg_split( '/\r\n|\r|\n/', sanitize_textarea_field( is_string( $value ) ? $value : '' ) ) as $line ) {
        $line = trim( $line );
        if ( '' !== $line && false !== strpos( $line, '|' ) ) {
            $clean[] = $line;
        }
    }
    return implode( "\n", $clean );
}

/**
 * Register all Scrollhaus Customizer panels, sections, settings, controls.
 *
 * @param WP_Customize_Manager $wp_customize Customizer manager.
 */
function scrollhaus_customize_register( $wp_customize ) {

    /* --- Panel ---------------------------------------------------------- */
    $wp_customize->add_panel(
        'scrollhaus_panel',
        array(
            'title'       => esc_html__( 'Scrollhaus', 'scrollhaus' ),
            'description' => esc_html__( 'Identity, homepage copy and colours for the Scrollhaus scroll-driven portfolio.', 'scrollhaus' ),
            'priority'    => 30,
        )
    );

    $add = function ( $section, $section_args, $fields ) use ( $wp_customize ) {
        $wp_customize->add_section( $section, array_merge( array( 'panel' => 'scrollhaus_panel' ), $section_args ) );
        foreach ( $fields as $id => $field ) {
            $wp_customize->add_setting(
                $id,
                array(
                    'default'           => isset( $field['default'] ) ? $field['default'] : '',
                    'sanitize_callback' => isset( $field['sanitize'] ) ? $field['sanitize'] : 'scrollhaus_sanitize_text',
                    'transport'         => isset( $field['transport'] ) ? $field['transport'] : 'refresh',
                )
            );
            $control_args = array(
                'label'   => $field['label'],
                'section' => $section,
            );
            if ( isset( $field['description'] ) ) {
                $control_args['description'] = $field['description'];
            }
            $type = isset( $field['type'] ) ? $field['type'] : 'text';
            if ( 'image' === $type ) {
                $wp_customize->add_control(
                    new WP_Customize_Image_Control( $wp_customize, $id, $control_args )
                );
            } elseif ( 'color' === $type ) {
                $wp_customize->add_control(
                    new WP_Customize_Color_Control( $wp_customize, $id, $control_args )
                );
            } else {
                $control_args['type'] = $type;
                $wp_customize->add_control( $id, $control_args );
            }
        }
    };

    /* --- Identity -------------------------------------------------------- */
    $add(
        'scrollhaus_identity',
        array(
            'title'    => esc_html__( 'Identity', 'scrollhaus' ),
            'priority' => 10,
        ),
        array(
            'scrollhaus_display_name'     => array(
                'label'   => esc_html__( 'Display name', 'scrollhaus' ),
                'default' => 'Alex Mercer',
            ),
            'scrollhaus_role'             => array(
                'label'   => esc_html__( 'Role / title', 'scrollhaus' ),
                'default' => 'Brand Designer & Art Director',
            ),
            'scrollhaus_location'         => array(
                'label'   => esc_html__( 'Location', 'scrollhaus' ),
                'default' => 'Portland, Oregon',
            ),
            'scrollhaus_since'            => array(
                'label'    => esc_html__( 'Designing since (year)', 'scrollhaus' ),
                'default'  => '2012',
                'sanitize' => 'absint',
            ),
            'scrollhaus_email'            => array(
                'label'    => esc_html__( 'Contact email', 'scrollhaus' ),
                'default'  => 'hello@example.com',
                'sanitize' => 'sanitize_email',
                'type'     => 'email',
            ),
            'scrollhaus_portrait'         => array(
                'label'   => esc_html__( 'Portrait image (About section)', 'scrollhaus' ),
                'type'    => 'image',
                'sanitize' => 'esc_url_raw',
            ),
            'scrollhaus_availability'     => array(
                'label'   => esc_html__( 'Availability badge text', 'scrollhaus' ),
                'default' => 'Booking new projects for next season',
            ),
        )
    );

    /* --- Homepage copy --------------------------------------------------- */
    $add(
        'scrollhaus_homepage',
        array(
            'title'    => esc_html__( 'Homepage Copy', 'scrollhaus' ),
            'priority' => 20,
        ),
        array(
            'scrollhaus_hero_lede'     => array(
                'label'   => esc_html__( 'Hero lede (under the name)', 'scrollhaus' ),
                'type'    => 'textarea',
                'sanitize' => 'scrollhaus_sanitize_textarea',
                'default' => 'Thoughtful brand identity and art direction for companies and everything they touch — identity, print and digital, made to hold up over time.',
            ),
            'scrollhaus_about_heading' => array(
                'label'   => esc_html__( 'About heading', 'scrollhaus' ),
                'default' => 'Independent Brand Designer',
            ),
            'scrollhaus_about_text'    => array(
                'label'   => esc_html__( 'About text', 'scrollhaus' ),
                'type'    => 'textarea',
                'sanitize' => 'scrollhaus_sanitize_textarea',
                'default' => 'I am an independent designer working from Portland, helping founders and teams turn fuzzy ideas into identities with a point of view. Ideas that hold up over time, type set with care, and the small details people feel even when they cannot name them.',
            ),
            'scrollhaus_work_heading'  => array(
                'label'   => esc_html__( 'Work section heading', 'scrollhaus' ),
                'default' => 'Selected Work',
            ),
            'scrollhaus_contact_heading' => array(
                'label'   => esc_html__( 'Contact heading', 'scrollhaus' ),
                'default' => "Let's make something",
            ),
            'scrollhaus_contact_text'  => array(
                'label'   => esc_html__( 'Contact text', 'scrollhaus' ),
                'type'    => 'textarea',
                'sanitize' => 'scrollhaus_sanitize_textarea',
                'default' => 'Tell me about your project, your timeline and where you want the brand to go. I reply to every serious enquiry within two working days.',
            ),
            'scrollhaus_cta_label'     => array(
                'label'   => esc_html__( 'Call-to-action label', 'scrollhaus' ),
                'default' => 'Copy email',
            ),
        )
    );

    /* --- Stats ------------------------------------------------------------ */
    $stat_fields = array();
    for ( $i = 1; $i <= 3; $i++ ) {
        /* translators: %d: stat number. */
        $stat_fields[ 'scrollhaus_stat_' . $i . '_value' ] = array(
            'label'   => sprintf( esc_html__( 'Stat %d — value', 'scrollhaus' ), $i ),
            'default' => scrollhaus_default_stat( $i, 'value' ),
        );
        /* translators: %d: stat number. */
        $stat_fields[ 'scrollhaus_stat_' . $i . '_label' ] = array(
            'label'   => sprintf( esc_html__( 'Stat %d — label', 'scrollhaus' ), $i ),
            'default' => scrollhaus_default_stat( $i, 'label' ),
        );
    }
    $add(
        'scrollhaus_stats',
        array(
            'title'    => esc_html__( 'Stats (By the Numbers)', 'scrollhaus' ),
            'priority' => 30,
        ),
        $stat_fields
    );

    /* --- Services ---------------------------------------------------------- */
    $add(
        'scrollhaus_services_section',
        array(
            'title'    => esc_html__( 'Services', 'scrollhaus' ),
            'priority' => 40,
        ),
        array(
            'scrollhaus_services' => array(
                'label'       => esc_html__( 'Services list', 'scrollhaus' ),
                'description' => esc_html__( 'One service per line, in this format: Name | item, item, item', 'scrollhaus' ),
                'type'        => 'textarea',
                'sanitize'    => 'scrollhaus_sanitize_services',
                'default'     => scrollhaus_default_services_text(),
            ),
        )
    );

    /* --- Journey ----------------------------------------------------------- */
    $add(
        'scrollhaus_journey_section',
        array(
            'title'    => esc_html__( 'Journey', 'scrollhaus' ),
            'priority' => 50,
        ),
        array(
            'scrollhaus_journey' => array(
                'label'       => esc_html__( 'Milestones', 'scrollhaus' ),
                'description' => esc_html__( 'One milestone per line, in this format: Year | Title | Text', 'scrollhaus' ),
                'type'        => 'textarea',
                'sanitize'    => 'scrollhaus_sanitize_journey',
                'default'     => scrollhaus_default_journey_text(),
            ),
        )
    );

    /* --- FAQ --------------------------------------------------------------- */
    $add(
        'scrollhaus_faq_section',
        array(
            'title'    => esc_html__( 'FAQ Page Items', 'scrollhaus' ),
            'priority' => 60,
        ),
        array(
            'scrollhaus_faq_items' => array(
                'label'       => esc_html__( 'FAQ items', 'scrollhaus' ),
                'description' => esc_html__( 'One item per line, in this format: Question | Answer. Shown on the page using the FAQ template.', 'scrollhaus' ),
                'type'        => 'textarea',
                'sanitize'    => 'scrollhaus_sanitize_faq',
                'default'     => scrollhaus_default_faq_text(),
            ),
        )
    );

    /* --- Colors ------------------------------------------------------------ */
    $add(
        'scrollhaus_colors',
        array(
            'title'    => esc_html__( 'Colors', 'scrollhaus' ),
            'priority' => 70,
        ),
        array(
            'scrollhaus_color_line' => array(
                'label'    => esc_html__( 'Accent / line colour', 'scrollhaus' ),
                'type'     => 'color',
                'sanitize' => 'sanitize_hex_color',
                'default'  => '#2234E0',
                'transport' => 'postMessage',
            ),
            'scrollhaus_color_bg'   => array(
                'label'    => esc_html__( 'Background colour', 'scrollhaus' ),
                'type'     => 'color',
                'sanitize' => 'sanitize_hex_color',
                'default'  => '#ECEAE2',
                'transport' => 'postMessage',
            ),
            'scrollhaus_color_ink'  => array(
                'label'    => esc_html__( 'Ink (text) colour', 'scrollhaus' ),
                'type'     => 'color',
                'sanitize' => 'sanitize_hex_color',
                'default'  => '#121413',
                'transport' => 'postMessage',
            ),
        )
    );

    /* --- Socials ----------------------------------------------------------- */
    $social_fields = array();
    foreach ( scrollhaus_social_networks() as $key => $label ) {
        $social_fields[ 'scrollhaus_social_' . $key ] = array(
            /* translators: %s: social network name. */
            'label'    => sprintf( esc_html__( '%s URL', 'scrollhaus' ), $label ),
            'type'     => 'url',
            'sanitize' => 'esc_url_raw',
        );
    }
    $add(
        'scrollhaus_socials',
        array(
            'title'    => esc_html__( 'Social Links', 'scrollhaus' ),
            'priority' => 80,
        ),
        $social_fields
    );

    /* --- Footer ------------------------------------------------------------ */
    $add(
        'scrollhaus_footer_section',
        array(
            'title'    => esc_html__( 'Footer', 'scrollhaus' ),
            'priority' => 90,
        ),
        array(
            'scrollhaus_footer_note' => array(
                'label'   => esc_html__( 'Footer note', 'scrollhaus' ),
                'default' => 'Built with Scrollhaus — a scroll-driven portfolio theme.',
            ),
        )
    );

    // Make the built-in site title refresh live where trivial.
    if ( isset( $wp_customize->selective_refresh ) ) {
        $wp_customize->get_setting( 'blogname' )->transport        = 'postMessage';
        $wp_customize->get_setting( 'blogdescription' )->transport = 'postMessage';
    }
}
add_action( 'customize_register', 'scrollhaus_customize_register' );
