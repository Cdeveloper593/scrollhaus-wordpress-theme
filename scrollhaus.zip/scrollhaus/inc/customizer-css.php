<?php
/**
 * Output Customizer colours as CSS variables, and convert hex to RGB
 * for the scene engine's canvas palette.
 *
 * @package Scrollhaus
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Convert a hex colour to an [r, g, b] array.
 *
 * @param string $hex Hex colour, with or without '#'.
 * @return array<int,int>|null
 */
function scrollhaus_hex_to_rgb( $hex ) {
    $hex = ltrim( (string) $hex, '#' );
    if ( 3 === strlen( $hex ) ) {
        $hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
    }
    if ( 6 !== strlen( $hex ) || ! ctype_xdigit( $hex ) ) {
        return null;
    }
    return array(
        hexdec( substr( $hex, 0, 2 ) ),
        hexdec( substr( $hex, 2, 2 ) ),
        hexdec( substr( $hex, 4, 2 ) ),
    );
}

/**
 * Print the :root overrides for Customizer colours in the head.
 * Runs late (priority 20) so it wins over the enqueued stylesheets.
 */
function scrollhaus_customizer_css() {
    $bg   = sanitize_hex_color( (string) scrollhaus_mod( 'scrollhaus_color_bg', '#ECEAE2' ) );
    $ink  = sanitize_hex_color( (string) scrollhaus_mod( 'scrollhaus_color_ink', '#121413' ) );
    $line = sanitize_hex_color( (string) scrollhaus_mod( 'scrollhaus_color_line', '#2234E0' ) );

    if ( ! $bg && ! $ink && ! $line ) {
        return;
    }

    echo "<style id=\"scrollhaus-customizer-css\">\n:root {\n";
    if ( $bg ) {
        echo '--bg: ' . esc_html( $bg ) . ";\n";
    }
    if ( $ink ) {
        echo '--ink: ' . esc_html( $ink ) . ";\n";
    }
    if ( $line ) {
        echo '--line: ' . esc_html( $line ) . ";\n";
    }
    echo "}\n</style>\n";
}
add_action( 'wp_head', 'scrollhaus_customizer_css', 20 );
