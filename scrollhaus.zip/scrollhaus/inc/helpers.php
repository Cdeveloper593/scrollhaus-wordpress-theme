<?php
/**
 * Small parsing / formatting helpers shared by templates.
 *
 * @package Scrollhaus
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Wrapper around get_theme_mod() with a Scrollhaus default fallback.
 *
 * @param string $key     Theme mod key (without prefix handling — full key).
 * @param mixed  $default Default when the mod is not set.
 * @return mixed
 */
function scrollhaus_mod( $key, $default = '' ) {
    $value = get_theme_mod( $key, null );
    if ( null === $value || '' === $value ) {
        return $default;
    }
    return $value;
}

/**
 * The three homepage stats from the Customizer.
 *
 * @return array<int, array{value:string,label:string}>
 */
function scrollhaus_stats() {
    $stats = array();
    for ( $i = 1; $i <= 3; $i++ ) {
        $stats[] = array(
            'value' => (string) scrollhaus_mod( 'scrollhaus_stat_' . $i . '_value', scrollhaus_default_stat( $i, 'value' ) ),
            'label' => (string) scrollhaus_mod( 'scrollhaus_stat_' . $i . '_label', scrollhaus_default_stat( $i, 'label' ) ),
        );
    }
    return $stats;
}

/**
 * Built-in defaults for the demo persona stats.
 *
 * @param int    $index 1–3.
 * @param string $part  'value' or 'label'.
 * @return string
 */
function scrollhaus_default_stat( $index, $part ) {
    $defaults = array(
        1 => array( 'value' => '2012', 'label' => 'Designing since' ),
        2 => array( 'value' => '180+', 'label' => 'Projects shipped' ),
        3 => array( 'value' => '14', 'label' => 'Awards & mentions' ),
    );
    return isset( $defaults[ $index ][ $part ] ) ? $defaults[ $index ][ $part ] : '';
}

/**
 * Parse the Customizer services textarea.
 *
 * Format — one service per line:
 *   Name | item one, item two, item three
 *
 * @return array<int, array{name:string,items:array<int,string>}>
 */
function scrollhaus_services_parsed() {
    $raw = (string) scrollhaus_mod( 'scrollhaus_services', scrollhaus_default_services_text() );
    return scrollhaus_parse_services_text( $raw );
}

/**
 * Parse services text (also used by the Customizer sanitizer).
 *
 * @param string $raw Raw textarea value.
 * @return array<int, array{name:string,items:array<int,string>}>
 */
function scrollhaus_parse_services_text( $raw ) {
    $services = array();
    foreach ( preg_split( '/\r\n|\r|\n/', (string) $raw ) as $line ) {
        $line = trim( $line );
        if ( '' === $line ) {
            continue;
        }
        $parts = array_map( 'trim', explode( '|', $line, 2 ) );
        $items = array();
        if ( isset( $parts[1] ) && '' !== $parts[1] ) {
            $items = array_values( array_filter( array_map( 'trim', explode( ',', $parts[1] ) ) ) );
        }
        $services[] = array(
            'name'  => $parts[0],
            'items' => $items,
        );
    }
    return $services;
}

/**
 * Default services textarea content (fictional demo persona).
 *
 * @return string
 */
function scrollhaus_default_services_text() {
    return implode(
        "\n",
        array(
            'Brand Identity | Logo design, Typography and colour systems, Guidelines and brand playbooks',
            'Art Direction | Campaign concepts, Art direction and imagery, Set and shoot direction',
            'Print & Editorial | Brand books, Brochures and collateral, Editorial design and layouts',
            'Web & Digital | Web design, Digital assets and social, Presentation design',
            'Brand Strategy | Positioning and differentiation, Audience definition, Voice, mission and vision',
        )
    );
}

/**
 * Parse the Customizer journey textarea.
 *
 * Format — one milestone per line:
 *   Year | Title | Text
 *
 * @return array<int, array{year:string,title:string,text:string}>
 */
function scrollhaus_milestones_parsed() {
    $raw = (string) scrollhaus_mod( 'scrollhaus_journey', scrollhaus_default_journey_text() );
    return scrollhaus_parse_journey_text( $raw );
}

/**
 * Parse journey text (also used by the Customizer sanitizer).
 *
 * @param string $raw Raw textarea value.
 * @return array<int, array{year:string,title:string,text:string}>
 */
function scrollhaus_parse_journey_text( $raw ) {
    $milestones = array();
    foreach ( preg_split( '/\r\n|\r|\n/', (string) $raw ) as $line ) {
        $line = trim( $line );
        if ( '' === $line ) {
            continue;
        }
        $parts      = array_map( 'trim', explode( '|', $line ) );
        $milestones[] = array(
            'year'  => isset( $parts[0] ) ? $parts[0] : '',
            'title' => isset( $parts[1] ) ? $parts[1] : '',
            'text'  => isset( $parts[2] ) ? $parts[2] : '',
        );
    }
    return $milestones;
}

/**
 * Default journey textarea content (fictional demo persona).
 *
 * @return string
 */
function scrollhaus_default_journey_text() {
    return implode(
        "\n",
        array(
            '2012 | First studio job | Started as a junior designer at a small Portland studio and fell for identity work.',
            '2015 | Senior designer | Led rebrands for regional clients and learned to present work that survives the room.',
            '2018 | Went independent | Traded the studio desk for a home office, a short client list and long-term relationships.',
            '2022 | Founded a small studio | Brought in collaborators — a photographer, a writer and a developer — under one roof.',
            '2026 | Today | Still designing, still learning. Booking new identity and art-direction projects for next season.',
        )
    );
}

/**
 * Parse the Customizer FAQ textarea.
 *
 * Format — one item per line:
 *   Question | Answer
 *
 * @return array<int, array{q:string,a:string}>
 */
function scrollhaus_faq_parsed() {
    $raw = (string) scrollhaus_mod( 'scrollhaus_faq_items', scrollhaus_default_faq_text() );
    $items = array();
    foreach ( preg_split( '/\r\n|\r|\n/', $raw ) as $line ) {
        $line = trim( $line );
        if ( '' === $line || false === strpos( $line, '|' ) ) {
            continue;
        }
        $parts   = array_map( 'trim', explode( '|', $line, 2 ) );
        $items[] = array(
            'q' => $parts[0],
            'a' => isset( $parts[1] ) ? $parts[1] : '',
        );
    }
    return $items;
}

/**
 * Default FAQ textarea content (fictional, generic for any freelancer).
 *
 * @return string
 */
function scrollhaus_default_faq_text() {
    return implode(
        "\n",
        array(
            'How do projects usually start? | With a short call and a lot of questions. You get a written proposal with scope, timeline and a fixed price before any design work begins.',
            'How long does a brand identity take? | Most identities take four to eight weeks, depending on how many directions we explore and how quickly feedback comes back.',
            'Do you work with clients outside your city? | Yes — most projects run remotely with weekly check-ins, shared boards and clear milestones.',
            'What do I receive at the end? | Final logo files in every format you need, a compact brand playbook, and the working files we agreed on in the proposal.',
            'Can you help with an existing brand? | Absolutely. Refreshes, extensions and art direction for established brands are a big part of the studio practice.',
        )
    );
}

/**
 * The six project-card layout tuples used by the scroll scene.
 *
 * Each tuple: x, y, width (vw), aspect ratio, anchor x, anchor y.
 * Mirrors the reference layout set and cycles for any project count.
 *
 * @return array<int, array{0:float,1:float,2:int,3:string,4:float,5:float}>
 */
function scrollhaus_project_layouts() {
    return array(
        array( -0.22, -0.02, 30, '4/3', 0.05, 0.30 ),
        array( 0.21, 0.05, 30, '4/3', -0.02, -0.30 ),
        array( -0.18, 0.00, 34, '16/9', 0.26, 0.34 ),
        array( 0.19, -0.04, 34, '16/9', 0.00, 0.32 ),
        array( -0.24, 0.03, 25, '3/2', 0.04, -0.30 ),
        array( 0.23, 0.00, 25, '3/2', -0.12, 0.36 ),
    );
}

/**
 * Layout for the project card at a given index (cycles every six).
 *
 * @param int $index Zero-based card index.
 * @return array Layout tuple plus computed 'side' and pixel widths.
 */
function scrollhaus_project_layout( $index ) {
    $layouts = scrollhaus_project_layouts();
    $tuple   = $layouts[ $index % count( $layouts ) ];
    $widths  = array(
        30 => array( 260, 560 ),
        34 => array( 280, 640 ),
        25 => array( 230, 460 ),
    );
    $w = isset( $widths[ $tuple[2] ] ) ? $widths[ $tuple[2] ] : array( 260, 560 );
    return array(
        'x'       => $tuple[0],
        'y'       => $tuple[1],
        'width'   => $tuple[2],
        'ratio'   => $tuple[3],
        'anchorX' => $tuple[4],
        'anchorY' => $tuple[5],
        'side'    => $tuple[0] < 0 ? 'l' : 'r',
        'minPx'   => $w[0],
        'maxPx'   => $w[1],
    );
}

/**
 * Format a float the way the scene data attributes expect (trim zeros).
 *
 * @param float $number Number to format.
 * @return string
 */
function scrollhaus_num( $number ) {
    $formatted = rtrim( rtrim( number_format( (float) $number, 2, '.', '' ), '0' ), '.' );
    return '' === $formatted || '-0' === $formatted ? '0' : $formatted;
}

/**
 * Social links defined in the Customizer, key => label map.
 *
 * @return array<string,string>
 */
function scrollhaus_social_networks() {
    return array(
        'instagram' => __( 'Instagram', 'scrollhaus' ),
        'behance'   => __( 'Behance', 'scrollhaus' ),
        'dribbble'  => __( 'Dribbble', 'scrollhaus' ),
        'linkedin'  => __( 'LinkedIn', 'scrollhaus' ),
        'x'         => __( 'X', 'scrollhaus' ),
    );
}

/**
 * Social links that actually have a URL set.
 *
 * @return array<string, array{label:string,url:string}>
 */
function scrollhaus_socials() {
    $out = array();
    foreach ( scrollhaus_social_networks() as $key => $label ) {
        $url = (string) scrollhaus_mod( 'scrollhaus_social_' . $key, '' );
        if ( '' !== $url ) {
            $out[ $key ] = array(
                'label' => $label,
                'url'   => $url,
            );
        }
    }
    return $out;
}
