<?php
/**
 * Template tags: small output helpers used across templates.
 *
 * @package Scrollhaus
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Print the site identity mark (custom logo if set, otherwise the
 * Customizer display name, otherwise the site title).
 */
function scrollhaus_the_mark() {
    if ( has_custom_logo() ) {
        the_custom_logo();
        return;
    }
    $name = (string) scrollhaus_mod( 'scrollhaus_display_name', get_bloginfo( 'name' ) );
    $parts = explode( ' ', trim( $name ), 2 );
    echo '<a class="mark" href="' . esc_url( home_url( '/' ) ) . '" rel="home">';
    echo esc_html( $parts[0] );
    if ( isset( $parts[1] ) ) {
        echo ' <span>' . esc_html( $parts[1] ) . '</span>';
    }
    echo '</a>';
}

/**
 * Comma-separated discipline names for a project.
 *
 * @param int $post_id Project ID.
 * @return string
 */
function scrollhaus_project_disciplines( $post_id = 0 ) {
    $post_id = $post_id ? (int) $post_id : (int) get_the_ID();
    $terms   = get_the_terms( $post_id, 'discipline' );
    if ( ! $terms || is_wp_error( $terms ) ) {
        return '';
    }
    $names = wp_list_pluck( $terms, 'name' );
    return implode( ', ', $names );
}

/**
 * Gallery attachment IDs stored on a project.
 *
 * @param int $post_id Project ID.
 * @return array<int,int>
 */
function scrollhaus_project_gallery_ids( $post_id = 0 ) {
    $post_id = $post_id ? (int) $post_id : (int) get_the_ID();
    $raw     = get_post_meta( $post_id, '_scrollhaus_gallery', true );
    if ( ! is_array( $raw ) ) {
        return array();
    }
    return array_values( array_filter( array_map( 'absint', $raw ) ) );
}

/**
 * Project meta value shortcut.
 *
 * @param string $key     Meta key without the _scrollhaus_ prefix.
 * @param int    $post_id Project ID.
 * @return string
 */
function scrollhaus_project_meta( $key, $post_id = 0 ) {
    $post_id = $post_id ? (int) $post_id : (int) get_the_ID();
    return (string) get_post_meta( $post_id, '_scrollhaus_' . $key, true );
}

/**
 * Print the social link list (used in the footer and contact section).
 *
 * @param string $class Wrapper class.
 */
function scrollhaus_the_socials( $class = 'foot-socials' ) {
    $socials = scrollhaus_socials();
    if ( ! $socials ) {
        return;
    }
    echo '<nav class="' . esc_attr( $class ) . '" aria-label="' . esc_attr__( 'Social profiles', 'scrollhaus' ) . '">';
    foreach ( $socials as $social ) {
        echo '<a href="' . esc_url( $social['url'] ) . '" target="_blank" rel="noopener noreferrer">' . esc_html( $social['label'] ) . '</a>';
    }
    echo '</nav>';
}

/**
 * Posted-on line for blog posts.
 */
function scrollhaus_posted_on() {
    printf(
        '<span class="mono">%1$s &middot; %2$s</span>',
        esc_html( get_the_date() ),
        esc_html( get_the_author() )
    );
}
