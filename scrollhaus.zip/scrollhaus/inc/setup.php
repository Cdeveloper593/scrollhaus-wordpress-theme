<?php
/**
 * Theme setup: supports, menus, image sizes, editor styles.
 *
 * @package Scrollhaus
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Register theme defaults and supports.
 */
function scrollhaus_setup() {
    load_theme_textdomain( 'scrollhaus', get_template_directory() . '/languages' );

    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );
    add_theme_support( 'automatic-feed-links' );
    add_theme_support( 'responsive-embeds' );
    add_theme_support( 'align-wide' );
    add_theme_support( 'editor-styles' );
    add_theme_support( 'wp-block-styles' );
    add_theme_support(
        'custom-logo',
        array(
            'height'      => 68,
            'width'       => 340,
            'flex-height' => true,
            'flex-width'  => true,
            'header-text' => array( 'site-title' ),
        )
    );
    add_theme_support(
        'html5',
        array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' )
    );
    add_theme_support(
        'custom-background',
        array( 'default-color' => 'ECEAE2' )
    );

    register_nav_menus(
        array(
            'primary' => esc_html__( 'Primary Menu (overlay)', 'scrollhaus' ),
            'footer'  => esc_html__( 'Footer Menu', 'scrollhaus' ),
        )
    );

    add_image_size( 'scrollhaus-cover', 1200, 900, true );
    add_image_size( 'scrollhaus-gallery', 1600, 1200, false );

    if ( ! isset( $GLOBALS['content_width'] ) ) {
        $GLOBALS['content_width'] = 1200;
    }
}
add_action( 'after_setup_theme', 'scrollhaus_setup', 0 );

/**
 * Flush rewrite rules when the theme is activated, so the project
 * archive and singles resolve immediately.
 */
function scrollhaus_after_switch_theme() {
    scrollhaus_register_project_post_type();
    scrollhaus_register_discipline_taxonomy();
    flush_rewrite_rules();
}
add_action( 'after_switch_theme', 'scrollhaus_after_switch_theme' );

/**
 * Editor stylesheet so the block editor roughly matches the front end.
 *
 * @param array $css Array of editor CSS URLs.
 * @return array
 */
function scrollhaus_editor_styles( $css ) {
    $css[] = 'assets/css/editor.css';
    return $css;
}
add_filter( 'editor_stylesheets', 'scrollhaus_editor_styles' );
