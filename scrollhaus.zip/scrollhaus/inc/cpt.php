<?php
/**
 * Project custom post type and Discipline taxonomy.
 *
 * @package Scrollhaus
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Register the `project` post type.
 */
function scrollhaus_register_project_post_type() {
    $labels = array(
        'name'               => esc_html_x( 'Projects', 'post type general name', 'scrollhaus' ),
        'singular_name'      => esc_html_x( 'Project', 'post type singular name', 'scrollhaus' ),
        'menu_name'          => esc_html__( 'Projects', 'scrollhaus' ),
        'add_new'            => esc_html__( 'Add New', 'scrollhaus' ),
        'add_new_item'       => esc_html__( 'Add New Project', 'scrollhaus' ),
        'edit_item'          => esc_html__( 'Edit Project', 'scrollhaus' ),
        'new_item'           => esc_html__( 'New Project', 'scrollhaus' ),
        'view_item'          => esc_html__( 'View Project', 'scrollhaus' ),
        'view_items'         => esc_html__( 'View Projects', 'scrollhaus' ),
        'search_items'       => esc_html__( 'Search Projects', 'scrollhaus' ),
        'not_found'          => esc_html__( 'No projects found.', 'scrollhaus' ),
        'not_found_in_trash' => esc_html__( 'No projects found in Trash.', 'scrollhaus' ),
        'featured_image'     => esc_html__( 'Project cover image', 'scrollhaus' ),
        'set_featured_image' => esc_html__( 'Set cover image', 'scrollhaus' ),
    );

    register_post_type(
        'project',
        array(
            'labels'             => $labels,
            'public'             => true,
            'publicly_queryable' => true,
            'show_ui'            => true,
            'show_in_menu'       => true,
            'show_in_rest'       => true,
            'menu_position'      => 5,
            'menu_icon'          => 'dashicons-portfolio',
            'query_var'          => true,
            'rewrite'            => array( 'slug' => 'projects', 'with_front' => false ),
            'capability_type'    => 'post',
            'has_archive'        => 'work',
            'hierarchical'       => false,
            'supports'           => array( 'title', 'editor', 'excerpt', 'thumbnail', 'custom-fields', 'revisions' ),
        )
    );
}
add_action( 'init', 'scrollhaus_register_project_post_type' );

/**
 * Register the `discipline` taxonomy for projects.
 */
function scrollhaus_register_discipline_taxonomy() {
    $labels = array(
        'name'          => esc_html_x( 'Disciplines', 'taxonomy general name', 'scrollhaus' ),
        'singular_name' => esc_html_x( 'Discipline', 'taxonomy singular name', 'scrollhaus' ),
        'search_items'  => esc_html__( 'Search Disciplines', 'scrollhaus' ),
        'all_items'     => esc_html__( 'All Disciplines', 'scrollhaus' ),
        'edit_item'     => esc_html__( 'Edit Discipline', 'scrollhaus' ),
        'update_item'   => esc_html__( 'Update Discipline', 'scrollhaus' ),
        'add_new_item'  => esc_html__( 'Add New Discipline', 'scrollhaus' ),
        'new_item_name' => esc_html__( 'New Discipline Name', 'scrollhaus' ),
        'menu_name'     => esc_html__( 'Disciplines', 'scrollhaus' ),
    );

    register_taxonomy(
        'discipline',
        array( 'project' ),
        array(
            'labels'            => $labels,
            'hierarchical'      => true,
            'public'            => true,
            'show_ui'           => true,
            'show_admin_column' => true,
            'show_in_rest'      => true,
            'query_var'         => true,
            'rewrite'           => array( 'slug' => 'discipline', 'with_front' => false ),
        )
    );
}
add_action( 'init', 'scrollhaus_register_discipline_taxonomy' );
