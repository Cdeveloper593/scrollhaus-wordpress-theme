<?php
/**
 * Project meta boxes: Project Details + Gallery.
 *
 * Stored meta:
 *   _scrollhaus_client   (string)
 *   _scrollhaus_year     (string)
 *   _scrollhaus_location (string)
 *   _scrollhaus_url      (URL)
 *   _scrollhaus_summary  (string, short summary shown in panels/cards)
 *   _scrollhaus_gallery  (array of attachment IDs)
 *
 * @package Scrollhaus
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Register the meta boxes.
 */
function scrollhaus_add_project_meta_boxes() {
    add_meta_box(
        'scrollhaus_project_details',
        esc_html__( 'Project Details', 'scrollhaus' ),
        'scrollhaus_render_details_meta_box',
        'project',
        'normal',
        'high'
    );
    add_meta_box(
        'scrollhaus_project_gallery',
        esc_html__( 'Project Gallery', 'scrollhaus' ),
        'scrollhaus_render_gallery_meta_box',
        'project',
        'normal',
        'default'
    );
}
add_action( 'add_meta_boxes', 'scrollhaus_add_project_meta_boxes' );

/**
 * Text fields shown in the Project Details box.
 *
 * @return array<string, array{label:string,type:string}>
 */
function scrollhaus_detail_fields() {
    return array(
        'client'   => array(
            'label' => __( 'Client', 'scrollhaus' ),
            'type'  => 'text',
        ),
        'year'     => array(
            'label' => __( 'Year', 'scrollhaus' ),
            'type'  => 'text',
        ),
        'location' => array(
            'label' => __( 'Location', 'scrollhaus' ),
            'type'  => 'text',
        ),
        'url'      => array(
            'label' => __( 'Project URL', 'scrollhaus' ),
            'type'  => 'url',
        ),
        'summary'  => array(
            'label' => __( 'Summary (one or two sentences, shown before the full description)', 'scrollhaus' ),
            'type'  => 'textarea',
        ),
    );
}

/**
 * Render the Project Details meta box.
 *
 * @param WP_Post $post Current project.
 */
function scrollhaus_render_details_meta_box( $post ) {
    wp_nonce_field( 'scrollhaus_save_project', 'scrollhaus_project_nonce' );
    echo '<table class="form-table"><tbody>';
    foreach ( scrollhaus_detail_fields() as $key => $field ) {
        $value = (string) get_post_meta( $post->ID, '_scrollhaus_' . $key, true );
        echo '<tr><th scope="row"><label for="scrollhaus_' . esc_attr( $key ) . '">' . esc_html( $field['label'] ) . '</label></th><td>';
        if ( 'textarea' === $field['type'] ) {
            echo '<textarea class="large-text" rows="3" id="scrollhaus_' . esc_attr( $key ) . '" name="scrollhaus_' . esc_attr( $key ) . '">' . esc_textarea( $value ) . '</textarea>';
        } else {
            echo '<input class="regular-text" type="' . esc_attr( $field['type'] ) . '" id="scrollhaus_' . esc_attr( $key ) . '" name="scrollhaus_' . esc_attr( $key ) . '" value="' . esc_attr( $value ) . '" />';
        }
        echo '</td></tr>';
    }
    echo '</tbody></table>';
}

/**
 * Render the Gallery meta box. The hidden input holds a comma-separated
 * list of attachment IDs; assets/js/admin-gallery.js manages it with the
 * WordPress media uploader.
 *
 * @param WP_Post $post Current project.
 */
function scrollhaus_render_gallery_meta_box( $post ) {
    $ids = scrollhaus_project_gallery_ids( $post->ID );
    echo '<div class="scrollhaus-gallery-box">';
    echo '<ul class="scrollhaus-gallery-list" style="display:flex;flex-wrap:wrap;gap:10px;margin:0 0 12px;padding:0;list-style:none;">';
    foreach ( $ids as $attachment_id ) {
        $thumb = wp_get_attachment_image( $attachment_id, 'thumbnail', false, array( 'style' => 'width:80px;height:80px;object-fit:cover;display:block;' ) );
        if ( ! $thumb ) {
            continue;
        }
        echo '<li data-id="' . esc_attr( (string) $attachment_id ) . '" style="position:relative;">' . wp_kses_post( $thumb );
        echo '<button type="button" class="button-link scrollhaus-gallery-remove" style="display:block;margin-top:4px;">' . esc_html__( 'Remove', 'scrollhaus' ) . '</button></li>';
    }
    echo '</ul>';
    echo '<input type="hidden" id="scrollhaus_gallery_ids" name="scrollhaus_gallery" value="' . esc_attr( implode( ',', $ids ) ) . '" />';
    echo '<button type="button" class="button scrollhaus-gallery-add">' . esc_html__( 'Add images', 'scrollhaus' ) . '</button> ';
    echo '<span class="description">' . esc_html__( 'Images appear in the project panel gallery, in this order. Drag-and-drop ordering is on the roadmap; remove and re-add to reorder.', 'scrollhaus' ) . '</span>';
    echo '</div>';
}

/**
 * Save handler for both meta boxes. Verifies nonce + capability, bails on
 * autosave, sanitizes every field.
 *
 * @param int $post_id Post being saved.
 */
function scrollhaus_save_project_meta( $post_id ) {
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
        return;
    }
    if ( ! isset( $_POST['scrollhaus_project_nonce'] ) ) {
        return;
    }
    $nonce = sanitize_text_field( wp_unslash( $_POST['scrollhaus_project_nonce'] ) );
    if ( ! wp_verify_nonce( $nonce, 'scrollhaus_save_project' ) ) {
        return;
    }
    if ( ! current_user_can( 'edit_post', $post_id ) ) {
        return;
    }
    if ( 'project' !== get_post_type( $post_id ) ) {
        return;
    }

    foreach ( scrollhaus_detail_fields() as $key => $field ) {
        $field_name = 'scrollhaus_' . $key;
        if ( ! isset( $_POST[ $field_name ] ) ) {
            continue;
        }
        $raw = wp_unslash( $_POST[ $field_name ] ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- sanitized per type below.
        if ( 'url' === $field['type'] ) {
            $value = esc_url_raw( is_string( $raw ) ? $raw : '' );
        } elseif ( 'textarea' === $field['type'] ) {
            $value = sanitize_textarea_field( is_string( $raw ) ? $raw : '' );
        } else {
            $value = sanitize_text_field( is_string( $raw ) ? $raw : '' );
        }
        update_post_meta( $post_id, '_scrollhaus_' . $key, $value );
    }

    if ( isset( $_POST['scrollhaus_gallery'] ) ) {
        $raw_gallery = sanitize_text_field( wp_unslash( $_POST['scrollhaus_gallery'] ) );
        $ids         = array();
        if ( '' !== $raw_gallery ) {
            foreach ( explode( ',', $raw_gallery ) as $piece ) {
                $attachment_id = absint( trim( $piece ) );
                if ( $attachment_id && 'attachment' === get_post_type( $attachment_id ) ) {
                    $ids[] = $attachment_id;
                }
            }
        }
        update_post_meta( $post_id, '_scrollhaus_gallery', $ids );
    }
}
add_action( 'save_post_project', 'scrollhaus_save_project_meta' );
