<?php
/**
 * Styles and scripts: Google Fonts, base styles, the scroll scene.
 *
 * @package Scrollhaus
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Version string based on file modification time (cache-busting for buyers
 * who edit CSS/JS directly), falling back to the theme version.
 *
 * @param string $relative_path Path relative to the theme root.
 * @return string
 */
function scrollhaus_asset_version( $relative_path ) {
    $file = get_template_directory() . '/' . ltrim( $relative_path, '/' );
    if ( file_exists( $file ) ) {
        return (string) filemtime( $file );
    }
    return SCROLLHAUS_VERSION;
}

/**
 * Enqueue front-end assets.
 */
function scrollhaus_enqueue_assets() {
    $uri = get_template_directory_uri();

    wp_enqueue_style(
        'scrollhaus-fonts',
        'https://fonts.googleapis.com/css2?family=Bebas+Neue&family=DM+Serif+Display:ital@0;1&family=Inter:wght@300;400;500;600&family=Space+Mono:wght@400;700&display=swap',
        array(),
        null
    );

    wp_enqueue_style(
        'scrollhaus-style',
        get_stylesheet_uri(),
        array( 'scrollhaus-fonts' ),
        scrollhaus_asset_version( 'style.css' )
    );

    $is_scene_page = is_front_page() || is_singular( 'project' );

    if ( $is_scene_page ) {
        wp_enqueue_style(
            'scrollhaus-scene',
            $uri . '/assets/css/scene.css',
            array( 'scrollhaus-style' ),
            scrollhaus_asset_version( 'assets/css/scene.css' )
        );

        wp_enqueue_script(
            'scrollhaus-scene',
            $uri . '/assets/js/scene.js',
            array(),
            scrollhaus_asset_version( 'assets/js/scene.js' ),
            array(
                'in_footer' => true,
                'strategy'  => 'defer',
            )
        );

        $line_color = (string) scrollhaus_mod( 'scrollhaus_color_line', '#2234E0' );
        $line_rgb   = array( 34, 52, 224 );
        if ( function_exists( 'scrollhaus_hex_to_rgb' ) ) {
            $parsed = scrollhaus_hex_to_rgb( $line_color );
            if ( is_array( $parsed ) ) {
                $line_rgb = $parsed;
            }
        }

        wp_localize_script(
            'scrollhaus-scene',
            'scrollhausScene',
            array(
                'line'    => $line_color,
                'lineRgb' => $line_rgb,
                'homeUrl' => home_url( '/' ),
            )
        );
    }

    if ( ! $is_scene_page ) {
        // Non-scene pages still need the overlay menu toggle; the scene
        // script handles it on scene pages, so only load one of them.
        wp_enqueue_script(
            'scrollhaus-menu',
            $uri . '/assets/js/menu.js',
            array(),
            scrollhaus_asset_version( 'assets/js/menu.js' ),
            array(
                'in_footer' => true,
                'strategy'  => 'defer',
            )
        );
    }

    if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
        wp_enqueue_script( 'comment-reply' );
    }
}
add_action( 'wp_enqueue_scripts', 'scrollhaus_enqueue_assets' );

/**
 * Enqueue the admin gallery uploader on project edit screens only.
 *
 * @param string $hook Current admin page hook.
 */
function scrollhaus_admin_enqueue( $hook ) {
    if ( 'post.php' !== $hook && 'post-new.php' !== $hook ) {
        return;
    }
    $screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
    if ( ! $screen || 'project' !== $screen->post_type ) {
        return;
    }
    wp_enqueue_media();
    wp_enqueue_script(
        'scrollhaus-admin-gallery',
        get_template_directory_uri() . '/assets/js/admin-gallery.js',
        array( 'jquery' ),
        scrollhaus_asset_version( 'assets/js/admin-gallery.js' ),
        true
    );
    wp_localize_script(
        'scrollhaus-admin-gallery',
        'scrollhausGallery',
        array(
            'title'  => esc_html__( 'Choose gallery images', 'scrollhaus' ),
            'button' => esc_html__( 'Add to gallery', 'scrollhaus' ),
            'remove' => esc_html__( 'Remove', 'scrollhaus' ),
        )
    );
}
add_action( 'admin_enqueue_scripts', 'scrollhaus_admin_enqueue' );
