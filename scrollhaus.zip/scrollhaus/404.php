<?php
/**
 * 404 template.
 *
 * @package Scrollhaus
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

get_header();
?>
<main class="page-main" id="world">
    <span class="k"><?php esc_html_e( 'Error 404', 'scrollhaus' ); ?></span>
    <h1 class="entry-title"><?php esc_html_e( 'Off the line', 'scrollhaus' ); ?></h1>
    <p class="lede" style="max-width:46ch"><?php esc_html_e( 'That page wandered off the path. Head back to the start of the line, or search for what you were after.', 'scrollhaus' ); ?></p>
    <p style="margin-top:2em"><?php get_search_form(); ?></p>
    <a class="cta" href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Back to the start', 'scrollhaus' ); ?></a>
</main>
<?php
get_footer();
