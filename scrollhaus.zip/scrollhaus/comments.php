<?php
/**
 * Comments template (basic, theme-styled).
 *
 * @package Scrollhaus
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( post_password_required() ) {
    return;
}
?>
<div id="comments" class="comments-area">
    <?php if ( have_comments() ) : ?>
        <h2 class="d" style="font-size:34px;white-space:normal">
            <?php
            printf(
                /* translators: %s: comment count. */
                esc_html( _n( '%s comment', '%s comments', get_comments_number(), 'scrollhaus' ) ),
                esc_html( number_format_i18n( get_comments_number() ) )
            );
            ?>
        </h2>
        <ol class="comment-list">
            <?php
            wp_list_comments(
                array(
                    'style'       => 'ol',
                    'short_ping'  => true,
                    'avatar_size' => 48,
                )
            );
            ?>
        </ol>
        <?php the_comments_pagination( array( 'mid_size' => 2 ) ); ?>
    <?php endif; ?>

    <?php if ( ! comments_open() && get_comments_number() && post_type_supports( get_post_type(), 'comments' ) ) : ?>
        <p class="mono"><?php esc_html_e( 'Comments are closed.', 'scrollhaus' ); ?></p>
    <?php endif; ?>

    <?php comment_form(); ?>
</div>
