<?php
/**
 * Template Name: Scrollhaus FAQ
 *
 * FAQ page: native <details>/<summary> items parsed from the Customizer
 * FAQ textarea (Appearance → Customize → Scrollhaus → FAQ Page Items),
 * below the page's own content. No JavaScript required.
 *
 * @package Scrollhaus
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

get_header();

$faq_items = scrollhaus_faq_parsed();
?>
<main class="page-main" id="world">
    <?php while ( have_posts() ) : ?>
        <?php the_post(); ?>
        <span class="k"><?php esc_html_e( 'Questions', 'scrollhaus' ); ?></span>
        <h1 class="entry-title"><?php the_title(); ?></h1>
        <div class="entry-content">
            <?php the_content(); ?>
        </div>
    <?php endwhile; ?>

    <div style="margin-top:2.4em">
        <?php foreach ( $faq_items as $item ) : ?>
            <details class="faq-item">
                <summary><?php echo esc_html( $item['q'] ); ?></summary>
                <p><?php echo esc_html( $item['a'] ); ?></p>
            </details>
        <?php endforeach; ?>
    </div>

    <a class="cta" href="<?php echo esc_url( home_url( '/#contact' ) ); ?>"><?php esc_html_e( 'Ask something else', 'scrollhaus' ); ?></a>
</main>
<?php
get_footer();
