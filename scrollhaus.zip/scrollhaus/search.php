<?php
/**
 * Search results template.
 *
 * @package Scrollhaus
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

get_header();
?>
<main class="page-main" id="world">
    <span class="k"><?php esc_html_e( 'Search', 'scrollhaus' ); ?></span>
    <h1 class="entry-title">
        <?php
        printf(
            /* translators: %s: search query. */
            esc_html__( 'Results for “%s”', 'scrollhaus' ),
            esc_html( get_search_query() )
        );
        ?>
    </h1>
    <?php get_search_form(); ?>

    <?php if ( have_posts() ) : ?>
        <div class="posts-grid">
            <?php while ( have_posts() ) : ?>
                <?php the_post(); ?>
                <article id="post-<?php the_ID(); ?>" <?php post_class( 'post-row' ); ?>>
                    <span class="mono"><?php echo esc_html( get_post_type_object( get_post_type() )->labels->singular_name ); ?></span>
                    <a href="<?php the_permalink(); ?>"><span class="d"><?php the_title(); ?></span></a>
                    <div class="small"><?php the_excerpt(); ?></div>
                </article>
            <?php endwhile; ?>
        </div>
        <?php the_posts_pagination( array( 'mid_size' => 2 ) ); ?>
    <?php else : ?>
        <p style="margin-top:2em"><?php esc_html_e( 'Nothing matched that search. Try a different word, or browse the work archive instead.', 'scrollhaus' ); ?></p>
        <a class="cta" href="<?php echo esc_url( get_post_type_archive_link( 'project' ) ); ?>"><?php esc_html_e( 'Browse work', 'scrollhaus' ); ?></a>
    <?php endif; ?>
</main>
<?php
get_footer();
