<?php
/**
 * Front page: the scroll-driven scene.
 *
 * Markup contract with assets/js/scene.js:
 *   <canvas id="cv">, <main id="world"> with .st sections, each holding
 *   .el elements positioned by data-p / data-mp / data-f / data-z, then
 *   #hud (with #ticks) and #spacer. Without JavaScript every section
 *   simply stacks — see the fallbacks in assets/css/scene.css.
 *
 * @package Scrollhaus
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

get_header();

$name        = (string) scrollhaus_mod( 'scrollhaus_display_name', get_bloginfo( 'name' ) );
$role        = (string) scrollhaus_mod( 'scrollhaus_role', '' );
$location    = (string) scrollhaus_mod( 'scrollhaus_location', '' );
$since       = (string) scrollhaus_mod( 'scrollhaus_since', '' );
$email       = (string) scrollhaus_mod( 'scrollhaus_email', '' );
$availability = (string) scrollhaus_mod( 'scrollhaus_availability', '' );
$portrait    = (string) scrollhaus_mod( 'scrollhaus_portrait', '' );
if ( '' === $portrait ) {
    $portrait = get_template_directory_uri() . '/assets/demo/portrait.svg';
}
$stats       = scrollhaus_stats();
$services    = scrollhaus_services_parsed();
$milestones  = scrollhaus_milestones_parsed();

$projects_query = new WP_Query(
    array(
        'post_type'      => 'project',
        'post_status'    => 'publish',
        'posts_per_page' => -1,
        'orderby'        => array( 'menu_order' => 'ASC', 'date' => 'ASC' ),
    )
);
$project_total = (int) $projects_query->found_posts;
?>

<canvas id="cv" aria-hidden="true"></canvas>

<main id="world">

    <?php /* --- Hero ------------------------------------------------------ */ ?>
    <section class="st" id="hero" data-label="<?php esc_attr_e( 'Home', 'scrollhaus' ); ?>" data-gap="0" data-hold=".45" data-a="0.455,0" data-ma="0.46,-0.04">
        <div class="el" data-p="0,-0.06" data-mp="0,-0.06" data-z="0" data-f="0,0.05">
            <h1 class="d bb h-name intro split"><?php echo esc_html( $name ); ?></h1>
        </div>
        <div class="el" data-p="-0.31,0.34" data-mp="-0.02,0.24" data-z="-.12" data-f="-.1,.1">
            <div class="h-cap">
                <span class="mono">
                    <?php echo esc_html( $role ); ?>
                    <?php if ( '' !== $since ) : ?>
                        &middot; <?php printf( esc_html__( 'Since %s', 'scrollhaus' ), esc_html( $since ) ); ?>
                    <?php endif; ?>
                    <?php if ( '' !== $location ) : ?>
                        &middot; <?php echo esc_html( $location ); ?>
                    <?php endif; ?>
                </span>
                <p class="lede"><?php echo esc_html( (string) scrollhaus_mod( 'scrollhaus_hero_lede', '' ) ); ?></p>
            </div>
        </div>
        <div class="el" data-p="0.4,0.36" data-mp="0.3,0.38" data-z="-.2" data-f="0,0">
            <button type="button" class="h-cue" data-go="about" aria-label="<?php esc_attr_e( 'Scroll to explore', 'scrollhaus' ); ?>">
                <i></i>
                <span class="mono"><?php esc_html_e( 'Scroll', 'scrollhaus' ); ?><span class="cue-x"> <?php esc_html_e( 'to explore', 'scrollhaus' ); ?></span></span>
            </button>
        </div>
    </section>

    <?php /* --- About ----------------------------------------------------- */ ?>
    <section class="st" id="about" data-label="<?php esc_attr_e( 'About', 'scrollhaus' ); ?>" data-gap="3.2" data-hold=".85" data-a="-0.06,-0.36" data-ma="0.38,-0.36">
        <div class="el" data-p="-0.24,0.02" data-mp="0,-0.19" data-z=".2" data-f="-.35,.05" data-r="10">
            <figure class="ab-fig" style="margin:0">
                <img src="<?php echo esc_url( $portrait ); ?>" alt="<?php echo esc_attr( $name ); ?>" loading="eager" />
            </figure>
        </div>
        <div class="el" data-p="0.14,-0.06" data-mp="0,0.2" data-z="-.08" data-f=".3,0" data-r="-8">
            <div class="ab-txt">
                <span class="mono"><?php esc_html_e( 'About', 'scrollhaus' ); ?></span>
                <p class="d bb ab-big split"><?php echo esc_html( (string) scrollhaus_mod( 'scrollhaus_about_heading', '' ) ); ?></p>
                <p class="lede"><?php echo esc_html( (string) scrollhaus_mod( 'scrollhaus_about_text', '' ) ); ?></p>
                <?php if ( '' !== $availability ) : ?>
                    <p><span class="pill"><?php echo esc_html( $availability ); ?></span></p>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <?php /* --- By the numbers -------------------------------------------- */ ?>
    <section class="st" id="numbers" data-dark="1" data-label="<?php esc_attr_e( 'By the numbers', 'scrollhaus' ); ?>" data-gap="3" data-hold=".7" data-a="0,0.36" data-ma="-0.4,0.42">
        <?php
        $stat_positions = array(
            array( '-0.3,-0.04', '-0.12,-0.27', '.55', '-.2,-.1' ),
            array( '0.04,0.12', '0.08,0', '0', '0,.15' ),
            array( '0.33,-0.14', '-0.12,0.27', '-.22', '.25,-.1' ),
        );
        ?>
        <?php foreach ( $stats as $stat_index => $stat ) : ?>
            <?php $pos = $stat_positions[ $stat_index % count( $stat_positions ) ]; ?>
            <div class="el" data-p="<?php echo esc_attr( $pos[0] ); ?>" data-mp="<?php echo esc_attr( $pos[1] ); ?>" data-z="<?php echo esc_attr( $pos[2] ); ?>" data-f="<?php echo esc_attr( $pos[3] ); ?>">
                <div class="num">
                    <span class="mono"><?php echo esc_html( $stat['label'] ); ?></span>
                    <p class="d t1">
                        <?php
                        // The middle stat counts up in the scene when its value
                        // starts with a number (e.g. "180+").
                        if ( 1 === $stat_index && preg_match( '/^(\d+)(.*)$/', $stat['value'], $m ) ) {
                            echo '<span id="count" data-target="' . esc_attr( $m[1] ) . '">' . esc_html( $m[1] ) . '</span>' . esc_html( $m[2] );
                        } else {
                            echo esc_html( $stat['value'] );
                        }
                        ?>
                    </p>
                </div>
            </div>
        <?php endforeach; ?>
    </section>

    <?php /* --- Journey ---------------------------------------------------- */ ?>
    <section class="st" id="journey" data-label="<?php esc_attr_e( 'Journey', 'scrollhaus' ); ?>" data-gap="3" data-hold=".5" data-a="0,0.3" data-ma="-0.38,0.3">
        <div class="el" data-p="0,-0.06" data-mp="0,-0.08" data-z="0" data-f="0,.1">
            <p class="d bb jr-h split"><?php esc_html_e( 'The journey', 'scrollhaus' ); ?></p>
        </div>
        <div class="el" data-p="0.12,0.15" data-mp="0.05,0.12" data-z="-.15" data-f=".1,0">
            <p class="d bb jr-sub"><?php esc_html_e( 'so far', 'scrollhaus' ); ?></p>
        </div>
    </section>

    <?php foreach ( $milestones as $milestone_index => $milestone ) : ?>
        <?php $flip = ( 0 === $milestone_index % 2 ); ?>
        <section class="st ms-st" data-label="<?php esc_attr_e( 'Journey', 'scrollhaus' ); ?>" data-gap="1.35" data-hold=".32" data-ease=".55" data-a="0,0.3" data-ma="-0.38,-0.03">
            <div class="el" data-p="0,0.3" data-mp="-0.38,-0.03" data-z="0" data-f="0,0">
                <i class="node" aria-hidden="true"></i>
            </div>
            <div class="el" data-p="<?php echo $flip ? '-0.2,-0.05' : '0.2,-0.05'; ?>" data-mp="0.08,-0.12" data-z=".25" data-f="<?php echo $flip ? '-0.25,0' : '0.25,0'; ?>">
                <p class="d yr"><?php echo esc_html( $milestone['year'] ); ?></p>
            </div>
            <div class="el" data-p="<?php echo $flip ? '0.2,0.04' : '-0.2,0.04'; ?>" data-mp="0.08,0.165" data-z="-.1" data-f="<?php echo $flip ? '0.2,0' : '-0.2,0'; ?>">
                <div class="ms">
                    <span class="mono"><?php echo esc_html( $milestone['title'] ); ?></span>
                    <p><?php echo esc_html( $milestone['text'] ); ?></p>
                </div>
            </div>
        </section>
    <?php endforeach; ?>

    <?php /* --- Services --------------------------------------------------- */ ?>
    <section class="st svc-st" id="services" data-dark="1" data-label="<?php esc_attr_e( 'What I do', 'scrollhaus' ); ?>" data-gap="3" data-hold="1.1" data-a="0.46,-0.21" data-ma="0.46,-0.25">
        <div class="el" data-p="0,-0.33" data-mp="0,-0.37" data-z=".35" data-f="0,-.1">
            <p class="d bb svc-h split"><?php esc_html_e( 'What I do', 'scrollhaus' ); ?></p>
        </div>
        <div class="el" data-p="0,0.1" data-mp="0,0.08" data-z="-.05" data-f="0,.1">
            <div class="svc-grid">
                <?php foreach ( $services as $service ) : ?>
                    <div class="svc">
                        <p class="d"><?php echo esc_html( $service['name'] ); ?></p>
                        <?php if ( $service['items'] ) : ?>
                            <ul>
                                <?php foreach ( $service['items'] as $item ) : ?>
                                    <li><?php echo esc_html( $item ); ?></li>
                                <?php endforeach; ?>
                            </ul>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <?php /* --- Work intro -------------------------------------------------- */ ?>
    <?php
    $work_heading = (string) scrollhaus_mod( 'scrollhaus_work_heading', 'Selected Work' );
    $work_words   = preg_split( '/\s+/', trim( $work_heading ) );
    $work_last    = '';
    if ( is_array( $work_words ) && count( $work_words ) > 1 ) {
        $work_last = (string) array_pop( $work_words );
    }
    $work_first = is_array( $work_words ) ? implode( ' ', $work_words ) : $work_heading;
    ?>
    <section class="st" id="work" data-label="<?php esc_attr_e( 'Work', 'scrollhaus' ); ?>" data-gap="3" data-hold=".55" data-a="0.4,0.26" data-ma="0.4,0.3">
        <div class="el" data-p="-0.12,-0.13" data-mp="-0.05,-0.064" data-z=".3" data-f="-.15,0">
            <p class="d bb wk-h split"><?php echo esc_html( $work_first ); ?></p>
        </div>
        <?php if ( '' !== $work_last ) : ?>
            <div class="el" data-p="0.14,0.11" data-mp="0.04,0.064" data-z="0" data-f=".15,0">
                <p class="d bb wk-h split"><?php echo esc_html( $work_last ); ?></p>
            </div>
        <?php endif; ?>
        <div class="el" data-p="-0.3,0.4" data-mp="0,0.3" data-z="-.15" data-f="0,0">
            <span class="mono">
                <?php
                printf(
                    /* translators: %d: number of published projects. */
                    esc_html( _n( '%d project', '%d projects', $project_total, 'scrollhaus' ) ),
                    $project_total // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- integer.
                );
                ?>
            </span>
        </div>
    </section>

    <?php /* --- Project cards (one scene stop per project) ------------------ */ ?>
    <?php if ( $projects_query->have_posts() ) : ?>
        <?php $card_index = 0; ?>
        <?php while ( $projects_query->have_posts() ) : ?>
            <?php
            $projects_query->the_post();
            $layout     = scrollhaus_project_layout( $card_index );
            $discipline = scrollhaus_project_disciplines();
            $cover_url  = '';
            if ( has_post_thumbnail() ) {
                $cover_url = (string) get_the_post_thumbnail_url( get_the_ID(), 'scrollhaus-cover' );
            }
            if ( '' === $cover_url ) {
                $cover_url = get_template_directory_uri() . '/assets/demo/project-' . ( ( $card_index % 6 ) + 1 ) . '.svg';
            }
            $ratio = $layout['ratio'];
            ?>
            <section class="st" id="project-<?php echo esc_attr( get_post_field( 'post_name', get_the_ID() ) ); ?>" data-label="<?php esc_attr_e( 'Work', 'scrollhaus' ); ?>" data-gap="<?php echo 0 === $card_index ? '2.2' : '1.55'; ?>" data-hold=".38" data-ease=".5" data-a="<?php echo esc_attr( scrollhaus_num( $layout['anchorX'] ) . ',' . scrollhaus_num( $layout['anchorY'] ) ); ?>" data-ma="<?php echo $layout['x'] < 0 ? '.43,.36' : '-.43,.36'; ?>">
                <div class="el" data-p="<?php echo esc_attr( scrollhaus_num( $layout['x'] ) . ',' . scrollhaus_num( $layout['y'] ) ); ?>" data-mp="0,-.02" data-f="<?php echo $layout['x'] < 0 ? '-.25,0' : '.25,0'; ?>" data-r="<?php echo $layout['x'] < 0 ? '18' : '-18'; ?>">
                    <a href="<?php the_permalink(); ?>" class="card <?php echo esc_attr( $layout['side'] ); ?>" style="width:clamp(<?php echo esc_attr( (string) $layout['minPx'] ); ?>px,<?php echo esc_attr( (string) $layout['width'] ); ?>vw,<?php echo esc_attr( (string) $layout['maxPx'] ); ?>px)">
                        <span class="fig" style="--ar:<?php echo esc_attr( $ratio ); ?>"><img src="<?php echo esc_url( $cover_url ); ?>" alt="<?php echo esc_attr( get_the_title() ); ?>" loading="lazy" decoding="async" /></span>
                        <span class="meta"><span class="mono"><?php echo esc_html( str_pad( (string) ( $card_index + 1 ), 2, '0', STR_PAD_LEFT ) . ' / ' . str_pad( (string) $project_total, 2, '0', STR_PAD_LEFT ) ); ?></span></span>
                        <span class="d"><?php the_title(); ?></span>
                        <?php if ( '' !== $discipline ) : ?>
                            <span class="small"><?php echo esc_html( $discipline ); ?></span>
                        <?php endif; ?>
                        <span class="mono open"><?php esc_html_e( 'View project', 'scrollhaus' ); ?><i aria-hidden="true"></i></span>
                    </a>
                </div>
            </section>
            <?php $card_index++; ?>
        <?php endwhile; ?>
        <?php wp_reset_postdata(); ?>
    <?php endif; ?>

    <?php /* --- Contact ------------------------------------------------------ */ ?>
    <section class="st" id="contact" data-label="<?php esc_attr_e( 'Contact', 'scrollhaus' ); ?>" data-gap="3.4" data-hold="1.2" data-a="0.44,-0.07" data-ma="0.47,-0.07" data-end="1">
        <div class="el" data-p="0,-0.06" data-mp="0,-0.06" data-z="0" data-f="0,0">
            <div class="ct-wrap">
                <h2 class="d bb ct-one split"><?php echo esc_html( (string) scrollhaus_mod( 'scrollhaus_contact_heading', '' ) ); ?></h2>
            </div>
        </div>
        <div class="el" data-p="0,0.13" data-mp="0,0.1" data-z="-.12" data-f="0,.1">
            <div class="ct-row">
                <span class="ct-mail" id="mail"><?php echo esc_html( $email ); ?></span>
                <button class="pill" id="copy" type="button"><?php echo esc_html( (string) scrollhaus_mod( 'scrollhaus_cta_label', '' ) ); ?></button>
            </div>
        </div>
        <div class="el" data-p="0,0.34" data-mp="0,0.32" data-z="-.2" data-f="0,.1">
            <div style="display:grid;gap:14px;justify-items:center;text-align:center">
                <p class="lede" style="max-width:52ch"><?php echo esc_html( (string) scrollhaus_mod( 'scrollhaus_contact_text', '' ) ); ?></p>
                <div class="ct-foot mono">
                    <?php foreach ( scrollhaus_socials() as $social ) : ?>
                        <a href="<?php echo esc_url( $social['url'] ); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html( $social['label'] ); ?></a>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </section>

</main>

<div id="spacer" aria-hidden="true"></div>

<div id="hud" class="mono" aria-hidden="true">
    <div class="trk"><i></i></div>
    <div id="ticks"></div>
    <i class="hd"></i>
    <div class="lb">
        <span id="hudn">01</span>
        <b id="hudl"><?php esc_html_e( 'Home', 'scrollhaus' ); ?></b>
    </div>
</div>

<?php
get_footer();
